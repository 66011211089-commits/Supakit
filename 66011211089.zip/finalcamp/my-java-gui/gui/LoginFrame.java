package gui; // <--- ต้องอยู่ใน package gui

import javax.swing.*;
import java.awt.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.json.JSONObject; // <--- (สำคัญ) import ตัวอ่าน JSON

public class LoginFrame extends JFrame {

    private final HttpClient httpClient = HttpClient.newHttpClient();
    private JTextField emailField;
    private JPasswordField passwordField; 
    private JButton loginButton;

    // (ใหม่) นี่คือ "Entry Point" ใหม่ของโปรแกรมเรา
    public static void main(String[] args) {
        
        // 
        // ---> 🇹🇭 นี่คือโค้ด "ตั้งค่าฟอนต์ไทย" ที่เพิ่มเข้ามาครับ <---
        // 
        try {
            // ตั้งค่าฟอนต์กลางสำหรับโปรแกรม (ใช้ Tahoma ถ้ามี, หรือฟอนต์อื่นที่รองรับไทย)
            Font thaiFont = new Font("Tahoma", Font.PLAIN, 14);
            UIManager.put("Label.font", thaiFont);
            UIManager.put("Button.font", thaiFont);
            UIManager.put("TextField.font", thaiFont);
            UIManager.put("PasswordField.font", thaiFont); // <--- เพิ่มสำหรับช่องรหัสผ่าน
            UIManager.put("Table.font", thaiFont);
            UIManager.put("TableHeader.font", thaiFont);
            UIManager.put("OptionPane.font", thaiFont); // <--- สำหรับหน้าต่าง Error
        } catch (Exception e) {
            System.err.println("Could not set Thai font.");
        }
        // 
        // ---> สิ้นสุดส่วนที่เพิ่มเข้ามา <---
        // 

        // โค้ดเดิม
        SwingUtilities.invokeLater(() -> {
            LoginFrame frame = new LoginFrame();
            frame.setVisible(true);
        });
    }

    public LoginFrame() {
        setTitle("Login - Camping Hand");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 

        // --- สร้าง UI ---
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Email (test@example.com):"));
        emailField = new JTextField("test@example.com"); 
        panel.add(emailField);

        panel.add(new JLabel("Password (123456):"));
        passwordField = new JPasswordField("123456"); 
        panel.add(passwordField);
        
        panel.add(new JLabel()); // ช่องว่าง
        loginButton = new JButton("Login");
        panel.add(loginButton);

        add(panel, BorderLayout.CENTER);

        // --- เพิ่ม Action ให้ปุ่ม Login ---
        loginButton.addActionListener(e -> attemptLogin());
    }

    private void attemptLogin() {
        String email = emailField.getText();
        String password = new String(passwordField.getPassword()); 

        String jsonPayload = String.format("{\"email\":\"%s\", \"password\":\"%s\"}", email, password);

        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .POST(HttpRequest.BodyPublishers.ofString(jsonPayload))
                    .uri(URI.create("http://localhost:8080/api/auth/login")) 
                    .header("Content-Type", "application/json")
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                // --- ล็อกอินสำเร็จ ---
                
                JSONObject jsonResponse = new JSONObject(response.body());
                String token = jsonResponse.getString("token");
                
                SwingUtilities.invokeLater(() -> {
                    AppGui productFrame = new AppGui(token); 
                    productFrame.setVisible(true);
                });

                this.dispose();

            } else {
                // --- ล็อกอินไม่สำเร็จ ---
                // (ตอนนี้ JOptionPane จะแสดงฟอนต์ไทยแล้ว)
                JOptionPane.showMessageDialog(this, 
                    "Login Failed! (Error: " + response.statusCode() + ")\nCheck email/password or if server is running.", 
                    "Login Error", 
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "Error connecting to server:\n" + ex.getMessage(), 
                "Connection Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
}