package gui; // <--- อยู่ใน package gui

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.json.JSONArray;
import org.json.JSONObject;

public class AppGui extends JFrame { 

    private static final HttpClient httpClient = HttpClient.newHttpClient();
    private static final String API_URL = "http://localhost:8080/api/products"; 

    private final String jwtToken; 
    private final JpaUserDetailsService jpaUserDetailsService; 
    
    private JTextField nameField;
    private JTextField priceField;
    private JTable productTable;
    private DefaultTableModel tableModel;

    public AppGui(String token) {
        this.jwtToken = "Bearer " + token; 
        this.jpaUserDetailsService = new JpaUserDetailsService(); 

        setTitle("Product Management Client (Logged In)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 500); 
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());

        String[] columnNames = {"ID", "Product Name", "Price"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
        productTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(productTable);

        JPanel inputPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        nameField = new JTextField();
        priceField = new JTextField();
        inputPanel.add(new JLabel("Product Name:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Price:"));
        inputPanel.add(priceField);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton fetchButton = new JButton("Fetch Products");
        JButton saveButton = new JButton("Save Product");
        buttonPanel.add(fetchButton);
        buttonPanel.add(saveButton);

        mainPanel.add(inputPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(mainPanel);

        fetchButton.addActionListener(e -> fetchProducts());
        saveButton.addActionListener(e -> saveProduct());
        
        // โหลดข้อมูลครั้งแรก
        fetchProducts();
    }

    // --- (อัปเกรด) Method สำหรับดึงข้อมูล ---
    private void fetchProducts() {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .GET()
                    .uri(URI.create(API_URL))
                    .header("Authorization", this.jwtToken) // <--- (สำคัญ!) ยื่นบัตรผ่าน
                    .build();

            httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    //.thenApply(HttpResponse::body) // <--- (ลบอันนี้ออก)
                    .thenAccept(response -> { // <--- (เปลี่ยนเป็นรับ response ทั้งก้อน)
                        
                        String jsonBody = response.body();
                        // 
                        // ---> นี่คือโค้ด DEBUG ที่เพิ่มเข้ามา <---
                        // 
                        System.out.println("Server Response (Fetch): " + jsonBody);

                        // 
                        // ---> นี่คือ "ตัวดักจับ ERROR" ที่เพิ่มเข้ามา <---
                        // 
                        if (response.statusCode() == 200) {
                            // ถ้าสำเร็จ (200) ค่อยอัปเดตตาราง
                            SwingUtilities.invokeLater(() -> {
                                updateTable(jsonBody);
                            });
                        } else {
                            // ถ้าไม่สำเร็จ (เช่น 403 Forbidden) ให้โชว์ Error
                            SwingUtilities.invokeLater(() -> {
                                JOptionPane.showMessageDialog(this, 
                                    "Error Fetching Data: " + jsonBody, 
                                    "API Error (Status: " + response.statusCode() + ")", 
                                    JOptionPane.ERROR_MESSAGE);
                            });
                        }
                    })
                    .exceptionally(ex -> {
                        SwingUtilities.invokeLater(() -> {
                             JOptionPane.showMessageDialog(this, "Error Fetching Data (Maybe Token Expired?):\n" + ex.getMessage(), "API Error", JOptionPane.ERROR_MESSAGE);
                        });
                        return null;
                    });
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error creating request: " + ex.getMessage(), "Request Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // --- (อัปเกรด) Method สำหรับบันทึกข้อมูล ---
    private void saveProduct() {
        try {
            String name = nameField.getText();
            double price = Double.parseDouble(priceField.getText());
            
            String jsonPayload = String.format(
                "{\"productName\":\"%s\", \"price\":%.2f, \"categoryId\": 7, \"conditionStatus\": \"new\"}", 
                name, price
            );

            HttpRequest request = HttpRequest.newBuilder()
                    .POST(HttpRequest.BodyPublishers.ofString(jsonPayload))
                    .uri(URI.create(API_URL))
                    .header("Content-Type", "application/json")
                    .header("Authorization", this.jwtToken) // <--- (สำคัญ!) ยื่นบัตรผ่าน
                    .build();

            httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                    .thenAccept(response -> { // <--- (แก้ให้รับ response ทั้งก้อน)
                        
                        // 
                        // ---> นี่คือโค้ด DEBUG ที่เพิ่มเข้ามา <---
                        // 
                        System.out.println("Server Response (Save): " + response.body());

                        // 
                        // ---> นี่คือ "ตัวดักจับ ERROR" ที่เพิ่มเข้ามา <---
                        // 
                        if (response.statusCode() == 200 || response.statusCode() == 201) { // 201 = Created
                            // ถ้าบันทึกสำเร็จ
                            SwingUtilities.invokeLater(() -> {
                                nameField.setText("");
                                priceField.setText("");
                                fetchProducts(); // รีเฟรชตาราง
                            });
                        } else {
                            // ถ้าบันทึกไม่สำเร็จ
                            SwingUtilities.invokeLater(() -> {
                                JOptionPane.showMessageDialog(this, 
                                    "Error saving product: " + response.body(), 
                                    "Save Error (Status: " + response.statusCode() + ")", 
                                    JOptionPane.ERROR_MESSAGE);
                            });
                        }
                    })
                    .exceptionally(ex -> {
                         SwingUtilities.invokeLater(() -> {
                             JOptionPane.showMessageDialog(this, "Error saving product: " + ex.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
                        });
                        return null;
                    });

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid price.", "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error creating save request: " + ex.getMessage(), "Request Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- (ไม่เปลี่ยนแปลง) Method สำหรับอัปเกตตาราง ---
    private void updateTable(String jsonBody) {
        try {
            tableModel.setRowCount(0); 
            JSONArray products = new JSONArray(jsonBody); // <--- (บรรทัดนี้ปลอดภัยแล้ว)

            for (int i = 0; i < products.length(); i++) {
                JSONObject product = products.getJSONObject(i);
                
                long id = product.getLong("id");
                String name = product.getString("productName"); 
                double price = product.getDouble("price");
                
                tableModel.addRow(new Object[]{id, name, price});
            }
        } catch (Exception e) {
            // (เราไม่ควรจะมาถึงตรงนี้แล้ว แต่เผื่อไว้)
            JOptionPane.showMessageDialog(this, "Error parsing server data: " + e.getMessage() + "\nBody was: " + jsonBody, "Data Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // (คลาสจำลอง)
    private class JpaUserDetailsService {}
}