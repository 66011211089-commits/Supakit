-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2025 at 11:50 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `campinghand_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_code` varchar(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_code`, `category_name`, `created_at`) VALUES
(1, 'C001', 'อุปกรณ์แคมป์ปิ้ง', '2025-10-27 18:13:06'),
(2, 'C002', 'เต็นท์ / ที่นอน', '2025-10-27 18:13:06'),
(3, 'C003', 'เตา / ทำอาหาร', '2025-10-27 18:13:06'),
(4, 'C004', 'เสื้อผ้า / รองเท้า', '2025-10-27 18:13:06'),
(5, 'C005', 'กระเป๋า / เป้สะพาย', '2025-10-27 18:13:06'),
(6, 'C006', 'ไฟ / โคมไฟ / ส่องสว่าง', '2025-10-27 18:13:06'),
(7, 'C007', 'อื่นๆ', '2025-10-27 18:19:15');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_detail` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT 0.00,
  `condition_status` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_code`, `product_name`, `product_detail`, `category_id`, `price`, `condition_status`, `image_path`, `created_at`) VALUES
(1, 'P001', 'แมวอ้วน', 'แมวอ้วนอึ่งปีศาจ', 7, 520.00, 'เน่า', 'uploads/prod_1761655015_ca28.jpg', '2025-10-27 18:25:59'),
(4, 'P002', 'แมวอึ่ง', 'อึ่งอ่างปีศาจ', 7, 500.00, 'เน่า', 'uploads/prod_1761655335_4526.jpg', '2025-10-28 12:42:15');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `phone`, `address`, `password_hash`, `role`, `enabled`, `created_at`) VALUES
(1, 'supakit', 'tainzeed909@gmail.com', '0956196067', '16/9 บ.ตาดทอง อ.เมือง จ.ยโสธร 35000', '$2y$10$1gn6S1tq6Ar4DQbhaTJl9.nMlLmEHwiwvvUF1LhrcNd4ocGtKo/AW', 'user', 1, '2025-10-27 17:06:14'),
(2, 'heremakchannel@gmail.com', 'heremakchannel@gmail.com', 'heremakchannel@gmail.com', '', '$2y$10$.rYRjdpzoM0pEPhCIydaYOAa6o06pxAFEmQIBqKla09JHqJ/bTMwu', 'admin', 1, '2025-10-27 17:15:49'),
(3, 'siraphop_test', 'test@example.com', '0812345678', 'Test address', '$2a$10$fiem5mgSCWfxz9Bbg08./.zKnvtAgOMx8HVsHuZxmd2Nuo590.RWi', 'user', 1, '2025-10-31 13:40:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_code` (`category_code`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD UNIQUE KEY `product_code` (`product_code`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
