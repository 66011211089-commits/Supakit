package com.example.my_spring_backend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories") // <--- URL หลักสำหรับหมวดหมู่
public class CategoryController {

    @Autowired // สั่งให้ Spring ฉีด CategoryRepository มาให้ใช้
    private CategoryRepository categoryRepository;

    // API: ดึงหมวดหมู่ทั้งหมด
    // GET http://localhost:8080/api/categories
    @GetMapping
    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    // API: เพิ่มหมวดหมู่ใหม่
    // POST http://localhost:8080/api/categories
    @PostMapping
    public Category createCategory(@RequestBody Category category) {
        // (ในอนาคต เราจะเช็ค categoryCode ซ้ำก่อน)
        return categoryRepository.save(category);
    }
}