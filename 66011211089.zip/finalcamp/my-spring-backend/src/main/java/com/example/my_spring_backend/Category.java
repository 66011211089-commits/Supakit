package com.example.my_spring_backend;

import jakarta.persistence.*;
import java.time.Instant;
import lombok.Data;

@Data
@Entity
@Table(name = "categories") // <--- บอกว่าให้ไปที่ตาราง "categories"
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "category_id")
    private Integer id;

    @Column(name = "category_code", unique = true, nullable = false)
    private String categoryCode;

    @Column(name = "category_name", nullable = false)
    private String categoryName;

    @Column(name = "created_at", insertable = false, updatable = false)
    private Instant createdAt;

    // หมายเหตุ: เรายังไม่จำเป็นต้องเพิ่ม List<Product> ในตอนนี้
    // เอาไว้ทีหลังตอนที่เราจะทำ API เชื่อมโยงครับ
}