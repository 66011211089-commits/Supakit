package com.example.my_spring_backend;

// ... (import อื่นๆ เหมือนเดิม) ...
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import lombok.Data;

@Data
@Entity
@Table(name = "products")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id")
    private Integer id;

    // ... (productCode, productName, ฯลฯ เหมือนเดิม) ...
    @Column(name = "product_code", unique = true, nullable = false)
    private String productCode;

    @Column(name = "product_name", nullable = false)
    private String productName;

    @Column(name = "product_detail", columnDefinition = "TEXT")
    private String productDetail;

    // --- (ส่วนที่ 1: แก้ไข) ---
    // ลบ private Integer categoryId; ของเก่าทิ้ง
    // แล้วแทนที่ด้วย 3 บรรทัดนี้:
    @ManyToOne // <--- ความสัมพันธ์: สินค้า "หลาย" ชิ้น อยู่ใน "หนึ่ง" หมวดหมู่
    @JoinColumn(name = "category_id", insertable = false, updatable = false) // <--- เชื่อมด้วยคอลัมน์ "category_id"
    private Category category; // <--- เราจะได้ Category Object ทั้งก้อนมาเลย

    // เรายังเก็บ category_id (แบบตัวเลข) ไว้ด้วย
    // เผื่อไว้ใช้ตอน "บันทึก" ข้อมูล จะได้ง่าย
    @Column(name = "category_id")
    private Integer categoryId;
    // --- สิ้นสุดส่วนที่ 1 ---


    @Column(name = "price", precision = 10, scale = 2)
    private BigDecimal price;

    @Column(name = "condition_status")
    private String conditionStatus;

    @Column(name = "image_path")
    private String imagePath;

    @Column(name = "created_at", insertable = false, updatable = false,
            columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Instant createdAt;
}