package com.example.my_spring_backend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager; 
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration; 
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy; // <--- ใหม่: import ตัวนี้
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter; // <--- ใหม่: import ตัวนี้

// (ใหม่) คุณต้อง import Filter ของคุณเข้ามา
// import com.example.my_spring_backend.filters.JwtAuthFilter; // <--- (ต้องหา Path ที่ถูกต้อง)

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private JpaUserDetailsService jpaUserDetailsService;

    // 
    // ---> ‼️ สำคัญมาก ‼️ <---
    // 
    @Autowired
    private JwtAuthFilter jwtAuthFilter; // <--- ใหม่: "ยาม" ของเรา
    // 
    // (ถ้าไฟล์ "ยาม" ของคุณไม่ได้ชื่อ JwtAuthFilter ให้เปลี่ยนชื่อตรงนี้ให้ถูกต้อง)
    // 

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) 
            
            // (ใหม่) บอก Spring ว่าเราจะไม่ใช้ Session (เพราะเราใช้ Token)
            .sessionManagement(session -> 
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            )
            
            .authorizeHttpRequests(authz -> authz
                .requestMatchers("/api/auth/**").permitAll() 
                .anyRequest().authenticated() 
            )
            .httpBasic(httpBasic -> httpBasic.disable())
            .formLogin(formLogin -> formLogin.disable())
            .userDetailsService(jpaUserDetailsService)

            // 
            // ---> ‼️ นี่คือส่วนที่เพิ่มเข้ามา ‼️ <---
            // (ใหม่) สั่งให้ "ยาม" (jwtAuthFilter) ไปยืนตรวจบัตร
            // "ก่อน" ที่ยามมาตรฐาน (UsernamePasswordAuthenticationFilter) จะเริ่มทำงาน
            // 
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}