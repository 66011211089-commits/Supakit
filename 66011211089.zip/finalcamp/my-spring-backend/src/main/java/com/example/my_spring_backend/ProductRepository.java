package com.example.my_spring_backend;

import org.springframework.data.jpa.repository.JpaRepository;

// แก้จาก <Product, Long> เป็น <Product, Integer>
// เพราะ ID ใน Product.java ของเราเป็น Integer
public interface ProductRepository extends JpaRepository<Product, Integer> {
}