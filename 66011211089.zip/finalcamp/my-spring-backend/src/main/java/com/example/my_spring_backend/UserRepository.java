package com.example.my_spring_backend;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional; // <--- import ใหม่

// <User, Integer> = จัดการ Entity User ที่มี ID เป็น Integer
public interface UserRepository extends JpaRepository<User, Integer> {

    // (ใหม่) เพิ่ม Method นี้
    // Spring Data JPA จะ "อ่านชื่อ Method" นี้
    // แล้วสร้าง query "SELECT * FROM users WHERE email = ?" ให้อัตโนมัติ
    Optional<User> findByEmail(String email);
}