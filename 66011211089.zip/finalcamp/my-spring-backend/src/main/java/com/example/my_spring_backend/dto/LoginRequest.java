package com.example.my_spring_backend.dto; // <--- (สำคัญ) package ต้องมี .dto

import lombok.Data;

@Data // Lombok: สร้าง Getter/Setter ให้อัตโนมัติ
public class LoginRequest {
    private String email;
    private String password;
}