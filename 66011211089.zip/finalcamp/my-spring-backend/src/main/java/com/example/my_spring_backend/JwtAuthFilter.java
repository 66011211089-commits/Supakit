package com.example.my_spring_backend;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component // <--- บอก Spring ว่านี่คือ "ชิ้นส่วน"
public class JwtAuthFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil; // <--- เรียก "ช่างกุญแจ" มาช่วย

    @Autowired
    private JpaUserDetailsService jpaUserDetailsService; // <--- เรียก "คนค้นข้อมูล User" มาช่วย

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {

        // 1. ดึง "Authorization Header" (บัตรผ่าน) ออกมา
        final String authHeader = request.getHeader("Authorization");

        // 2. ตรวจสอบว่าบัตรผ่านถูกต้องหรือไม่ (ต้องขึ้นต้นด้วย "Bearer ")
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response); // ถ้าไม่มีบัตร ก็ปล่อยผ่าน (เดี๋ยว Security Config จัดการเอง)
            return;
        }

        // 3. ถ้าบัตรดูโอเค ให้ตัดคำว่า "Bearer " ทิ้ง เพื่อเอาแต่ "ตัว Token"
        final String jwt = authHeader.substring(7); // "Bearer ".length() == 7

        // 4. ให้ "ช่างกุญแจ" (JwtUtil) ถอดรหัส Token เพื่อเอา "email" ออกมา
        final String userEmail = jwtUtil.extractUsername(jwt);

        // 5. ถ้าได้ email มา และ User คนนี้ยังไม่ได้ "เข้าระบบ" (ใน SecurityContextHolder)
        if (userEmail != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            
            // 6. ให้ "คนค้นข้อมูล" (JPA) ไปดึง UserDetails (ข้อมูล User) จาก email
            UserDetails userDetails = this.jpaUserDetailsService.loadUserByUsername(userEmail);

            // 7. ให้ "ช่างกุญแจ" ตรวจสอบว่า Token นี้ ถูกต้อง และเป็นของ User คนนี้จริงๆ
            if (jwtUtil.isTokenValid(jwt, userDetails)) {
                
                // 8. ถ้าทุกอย่างถูกต้อง "สร้างตั๋ว" (AuthenticationToken)
                UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                        userDetails,
                        null, // เราไม่จำเป็นต้องใส่รหัสผ่าน
                        userDetails.getAuthorities() // ใส่ "สิทธิ์" (ROLE) ของเขาเข้าไป
                );
                
                authToken.setDetails(
                        new WebAuthenticationDetailsSource().buildDetails(request)
                );

                // 9. "ปั๊มตรา" รับรองว่า User คนนี้เข้าระบบแล้ว
                SecurityContextHolder.getContext().setAuthentication(authToken);
            }
        }
        
        // 10. ปล่อยให้คำขอ (Request) เดินทางต่อไป
        filterChain.doFilter(request, response);
    }
}