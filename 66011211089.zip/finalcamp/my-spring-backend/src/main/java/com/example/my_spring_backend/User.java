package com.example.my_spring_backend;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.Collection; 
import java.util.List; 
import lombok.Data;
// --- import ของ Spring Security ---
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@Data
@Entity
@Table(name = "users")
public class User implements UserDetails { 

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Integer id;

    @Column(name = "username", nullable = false)
    private String username;

    @Column(name = "email", unique = true, nullable = false)
    private String email;

    @Column(name = "phone")
    private String phone;

    @Column(name = "address", columnDefinition = "TEXT")
    private String address;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash; 

    @Column(name = "role")
    private String role; 

    @Column(name = "created_at", insertable = false, updatable = false)
    private Instant createdAt;

    // 
    // ---> ‼️ (1) นี่คือ Field ที่ขาดไป ‼️ <---
    // 
    @Column(name = "enabled") // <--- เชื่อมกับคอลัมน์ "enabled" ใน XAMPP
    private boolean enabled;  // <--- สร้างตัวแปรมารับค่า (1 = true, 0 = false)
    

    // =================================================================
    // Method ที่ UserDetails (Spring Security) บังคับให้มี
    // =================================================================

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + this.role.toUpperCase()));
    }

    @Override
    public String getPassword() {
        return this.passwordHash; // <--- บอก Spring ว่ารหัสผ่านคือคอลัมน์นี้
    }

    @Override
    public String getUsername() {
        return this.email; // <--- (สำคัญ) เราใช้ "Email" ในการล็อกอิน
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    // 
    // ---> ‼️ (2) นี่คือ Method ที่ต้องแก้ ‼️ <---
    // 
    @Override
    public boolean isEnabled() {
        // ห้าม return true;
        // ให้คืนค่า "enabled" ที่อ่านมาจากฐานข้อมูล
        return this.enabled; 
    }
}