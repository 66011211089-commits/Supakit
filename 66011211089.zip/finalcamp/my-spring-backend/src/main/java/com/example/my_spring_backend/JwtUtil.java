package com.example.my_spring_backend;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Service // <--- บอก Spring ว่านี่คือ "บริการ"
public class JwtUtil {

    // (สำคัญ) นี่คือ "กุญแจลับ" ของเรา
    // (ในโลกจริง ห้าม hardcode แบบนี้ ให้ไปเก็บที่ application.properties)
    private static final String SECRET_KEY = "YoutSecretKeyMustBeVeryLongAndSecure_AtLeast256Bits_ThisIsAnExample";

    // สร้าง Token จาก UserDetails
    public String generateToken(UserDetails userDetails) {
        return generateToken(new HashMap<>(), userDetails);
    }

    // สร้าง Token (เวอร์ชันเต็ม)
    public String generateToken(Map<String, Object> extraClaims, UserDetails userDetails) {
        return Jwts.builder()
                .setClaims(extraClaims)
                .setSubject(userDetails.getUsername()) // "Subject" คือ email
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 10)) // Token มีอายุ 10 ชั่วโมง
                .signWith(getSignInKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    // ตรวจสอบว่า Token ถูกต้องหรือไม่
    public boolean isTokenValid(String token, UserDetails userDetails) {
        final String username = extractUsername(token);
        return (username.equals(userDetails.getUsername())) && !isTokenExpired(token);
    }

    // ตรวจสอบว่า Token หมดอายุหรือยัง
    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    // ดึง "วันหมดอายุ" ออกจาก Token
    private Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    // ดึง "Username" (email) ออกจาก Token
    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    // (Method หลัก) ดึง "ข้อมูล" (Claim) ใดๆ ออกจาก Token
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    // (Method หลัก) ถอดรหัส Token ทั้งก้อน
    private Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSignInKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    // สร้าง "กุญแจ" สำหรับเข้ารหัส/ถอดรหัส
    private Key getSignInKey() {
        byte[] keyBytes = Decoders.BASE64.decode(SECRET_KEY);
        return Keys.hmacShaKeyFor(keyBytes);
    }
}