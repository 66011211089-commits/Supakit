package com.example.my_spring_backend.dto;

// นี่คือ "กล่อง" DTO (Data Transfer Object) ที่เราใช้ส่ง Token กลับไป
public class AuthResponse {
    
    private String token;

    // 
    // ---> ‼️ นี่คือ "Constructor" ที่ AuthController ต้องการใช้ครับ ‼️ <---
    // 
    public AuthResponse(String token) {
        this.token = token;
    }

    // (Getter ที่จำเป็น)
    public String getToken() {
        return token;
    }

    // (Setter ที่จำเป็น)
    public void setToken(String token) {
        this.token = token;
    }
}