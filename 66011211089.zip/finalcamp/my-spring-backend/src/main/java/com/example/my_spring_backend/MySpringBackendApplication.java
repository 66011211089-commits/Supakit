package com.example.my_spring_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean; // <--- import ใหม่
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder; // <--- import ใหม่
import org.springframework.security.crypto.password.PasswordEncoder; // <--- import ใหม่

@SpringBootApplication
public class MySpringBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(MySpringBackendApplication.class, args);
    }

    // --- (ใหม่) เพิ่ม Bean นี้เข้าไป ---
    // สร้างเครื่องมือเข้ารหัสรหัสผ่าน (BCrypt)
    // ให้ Spring Boot รู้จัก และพร้อมฉีด (Inject) ไปใช้งาน
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    // --- สิ้นสุดส่วนใหม่ ---
}