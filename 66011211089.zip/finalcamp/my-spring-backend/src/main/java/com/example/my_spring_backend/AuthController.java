package com.example.my_spring_backend;

import com.example.my_spring_backend.dto.AuthResponse;
import com.example.my_spring_backend.dto.LoginRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails; // <--- (ใหม่) Import ตัวนี้
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserRepository userRepository;
    
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User newUser) {
        if (newUser.getRole() == null || newUser.getRole().isEmpty()) {
            newUser.setRole("user"); 
        }
        User savedUser = userRepository.save(newUser);
        return ResponseEntity.ok(savedUser);
    }
    

    // (Api Auth: Login)
    // POST http://localhost:8080/api/auth/login
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {

        // 1. ส่ง email/password ให้ "ผู้คุม" (AuthManager) ตรวจสอบ
        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(
                loginRequest.getEmail(),
                loginRequest.getPassword()
            )
        );
        
        // 2. ถ้าตรวจสอบผ่าน, ให้ "ปั๊มตรา" รับรอง (Set SecurityContext)
        SecurityContextHolder.getContext().setAuthentication(authentication);

        // 
        // ---> (3) นี่คือจุดที่แก้ครับ <---
        // 
        
        // 3.1 ดึง "UserDetails" (ข้อมูล User) ออกมาจาก "ตั๋ว" (Authentication)
        // (เพราะ JwtUtil ของเราต้องการ UserDetails ครับ)
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();

        // 3.2 เรียก "ช่างกุญแจ" (JwtUtil) มาสร้าง Token
        String token = jwtUtil.generateToken(userDetails); // <--- (เส้นแดงตรงนี้จะหายไป)

        // 4. ส่ง Token กลับไปให้ User (ห่อใน DTO)
        return ResponseEntity.ok(new AuthResponse(token)); // <--- (เส้นแดงตรงนี้จะหายไป)
    }
}