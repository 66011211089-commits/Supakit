package com.example.my_spring_backend;

// --- นี่คือ import ทั้งหมดที่ต้องใช้ (13 บรรทัด) ---
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;
// --- สิ้นสุด import ---


@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    // API: ดึงสินค้าทั้งหมด (เหมือนเดิม)
    // GET http://localhost:8080/api/products
    @GetMapping
    public List<Product> getAllProducts() {
        // findAll() จะทำการ JOIN Category มาให้เราอัตโนมัติ!
        return productRepository.findAll();
    }

    // API: ดึงสินค้า 1 ชิ้น (สำหรับหน้า Edit)
    // GET http://localhost:8080/api/products/1
    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Integer id) {
        Optional<Product> product = productRepository.findById(id);
        if (product.isPresent()) {
            return ResponseEntity.ok(product.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // API: เพิ่มสินค้าใหม่ (เหมือน admin_products.php)
    // POST http://localhost:8080/api/products
    @PostMapping
    public Product createProduct(@RequestBody Product product) {
        // (ยังไม่รองรับการอัปโหลดรูปในขั้นตอนนี้)
        // (เราต้อง gen product_code ก่อนบันทึกในอนาคต)
        
        // เราคาดว่า GUI จะส่ง "categoryId" (ตัวเลข) มาใน JSON
        // Spring Boot จะบันทึกมันลงคอลัมน์ category_id 
        return productRepository.save(product);
    }
    
    // API: อัปเดตสินค้า (เหมือน admin_product_edit.php)
    // PUT http://localhost:8080/api/products/1
    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Integer id, @RequestBody Product productDetails) {
        Optional<Product> optionalProduct = productRepository.findById(id);

        if (optionalProduct.isPresent()) {
            Product existingProduct = optionalProduct.get();
            
            // อัปเดตค่าจาก JSON ที่ส่งมา
            existingProduct.setProductName(productDetails.getProductName());
            existingProduct.setProductDetail(productDetails.getProductDetail());
            existingProduct.setPrice(productDetails.getPrice());
            existingProduct.setConditionStatus(productDetails.getConditionStatus());
            existingProduct.setCategoryId(productDetails.getCategoryId()); // <--- อัปเดต categoryId
            // (ยังไม่จัดการ image_path)

            Product updatedProduct = productRepository.save(existingProduct);
            return ResponseEntity.ok(updatedProduct);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // API: ลบสินค้า (เหมือน admin_product_delete.php)
    // DELETE http://localhost:8080/api/products/1
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable Integer id) {
        if (productRepository.existsById(id)) {
            productRepository.deleteById(id);
            // (เราต้องเพิ่มโค้ดลบรูปภาพในอนาคต)
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}