<?php
// config/db.php
$envPath = __DIR__ . '/.env';
if (!file_exists($envPath)) { $envPath = __DIR__ . '/env.sample'; }
$env = parse_ini_file($envPath, false, INI_SCANNER_RAW);

$host = $env['DB_HOST'] ?? 'localhost';
$name = $env['DB_NAME'] ?? 'camping_hand';
$user = $env['DB_USER'] ?? 'root';
$pass = $env['DB_PASS'] ?? '';

$mysqli = @new mysqli($host, $user, $pass, $name);
if ($mysqli->connect_errno) {
  http_response_code(500);
  header('Content-Type: application/json');
  echo json_encode(['error' => 'DB_CONNECT_ERROR', 'detail' => $mysqli->connect_error]);
  exit;
}
$mysqli->set_charset('utf8mb4');
?>
