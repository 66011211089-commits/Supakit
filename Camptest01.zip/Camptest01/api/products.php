<?php
require_once __DIR__.'/utils.php';
$fn = $_GET['fn'] ?? 'list';

if ($fn==='list') {
  $q = trim($_GET['q'] ?? '');
  if ($q) {
    $like = "%$q%";
    $stmt = $mysqli->prepare("SELECT p.*, c.name AS category_name, u.name AS seller_name
      FROM products p
      JOIN categories c ON p.category_id=c.category_id
      JOIN users u ON p.seller_id=u.user_id
      WHERE p.status='approved' AND (p.name LIKE ? OR c.name LIKE ?)
      ORDER BY p.created_at DESC");
    $stmt->bind_param('ss', $like,$like);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    ok($rows);
  } else {
    $res = $mysqli->query("SELECT p.*, c.name AS category_name, u.name AS seller_name
      FROM products p
      JOIN categories c ON p.category_id=c.category_id
      JOIN users u ON p.seller_id=u.user_id
      WHERE p.status='approved'
      ORDER BY p.created_at DESC");
    $rows = $res->fetch_all(MYSQLI_ASSOC);
    ok($rows);
  }
}

if ($fn==='detail') {
  $id = intval($_GET['id'] ?? 0);
  $stmt = $mysqli->prepare("SELECT p.*, c.name AS category_name, u.name AS seller_name
    FROM products p
    JOIN categories c ON p.category_id=c.category_id
    JOIN users u ON p.seller_id=u.user_id
    WHERE p.product_id=?");
  $stmt->bind_param('i', $id);
  $stmt->execute();
  $row = $stmt->get_result()->fetch_assoc();
  ok($row ?: []);
}

if ($fn==='create') {
  $pl = require_role(['seller','admin']);
  $in = json_input();
  $name = trim($in['name'] ?? '');
  $desc = trim($in['description'] ?? '');
  $category_id = intval($in['category_id'] ?? 0);
  $cond = $in['condition'] ?? 'B';
  $price = floatval($in['price'] ?? 0);
  $image = trim($in['image'] ?? '');
  $seller_id = $pl['uid'];
  if (!$name || !$category_id || $price<=0) fail('MISSING_FIELDS');
  $status = ($pl['role']==='admin') ? 'approved' : 'pending';
  $stmt = $mysqli->prepare("INSERT INTO products(name,description,category_id,seller_id,`condition`,price,image,status) VALUES(?,?,?,?,?,?,?,?)");
  $stmt->bind_param('ssiisdss', $name,$desc,$category_id,$seller_id,$cond,$price,$image,$status);
}

  $stmt->execute();
  $pid = $stmt->insert_id;
  $stmt2 = $mysqli->prepare("INSERT IGNORE INTO inventory(product_id, stock_qty) VALUES(?,1)");
  $stmt2->bind_param('i', $pid);
  $stmt2->execute();
  ok(['product_id'=>$pid, 'status'=>$status]);
}

if ($fn==='update_status') {
  require_role(['admin']);
  $in = json_input();
  $pid = intval($in['product_id'] ?? 0);
  $status = $in['status'] ?? 'approved';
  $stmt = $mysqli->prepare("UPDATE products SET status=? WHERE product_id=?");
  $stmt->bind_param('si', $status,$pid);
  $stmt->execute();
  ok(['updated'=>$stmt->affected_rows]);
}

if ($fn==='delete') {
  $pl = require_role(['admin']);
  $in = json_input();
  $pid = intval($in['product_id'] ?? 0);
  $stmt = $mysqli->prepare("DELETE FROM products WHERE product_id=?");
  $stmt->bind_param('i', $pid);
  $stmt->execute();
  ok(['deleted'=>$stmt->affected_rows]);
}

fail('UNKNOWN_FN',404);
