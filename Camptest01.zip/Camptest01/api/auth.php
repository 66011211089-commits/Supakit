<?php
require_once __DIR__.'/utils.php';

$method = $_GET['fn'] ?? '';

if ($method === 'register') {
  $in = json_input();
  $name = trim($in['name'] ?? '');
  $email = trim($in['email'] ?? '');
  $pass = $in['password'] ?? '';
  $role = in_array(($in['role'] ?? 'buyer'), ['buyer','seller']) ? $in['role'] : 'buyer';

  if (!$name || !$email || !$pass) fail('MISSING_FIELDS');
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('INVALID_EMAIL');

  $stmt = $mysqli->prepare("SELECT user_id FROM users WHERE email=?");
  $stmt->bind_param('s', $email);
  $stmt->execute();
  if ($stmt->get_result()->fetch_assoc()) fail('EMAIL_EXISTS', 409);

  $hash = password_hash($pass, PASSWORD_BCRYPT);
  $stmt = $mysqli->prepare("INSERT INTO users(name,email,role,password_hash) VALUES(?,?,?,?)");
  $stmt->bind_param('ssss', $name,$email,$role,$hash);
  $stmt->execute();
  ok(['user_id'=>$stmt->insert_id]);
}

if ($method === 'login') {
  $in = json_input();
  $email = trim($in['email'] ?? '');
  $pass = $in['password'] ?? '';
  if (!$email || !$pass) fail('MISSING_FIELDS');
  $stmt = $mysqli->prepare("SELECT user_id,name,email,role,password_hash FROM users WHERE email=?");
  $stmt->bind_param('s', $email);
  $stmt->execute();
  $u = $stmt->get_result()->fetch_assoc();
  if (!$u || !password_verify($pass, $u['password_hash'])) fail('INVALID_CREDENTIALS', 401);
  $token = sign_token($u);
  ok(['token'=>$token, 'user'=>['user_id'=>$u['user_id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role']]]);
}

if ($method === 'profile') {
  $pl = read_token();
  if (!$pl) fail('UNAUTHORIZED',401);
  $stmt = $mysqli->prepare("SELECT user_id,name,email,role,created_at FROM users WHERE user_id=?");
  $stmt->bind_param('i', $pl['uid']);
  $stmt->execute();
  $u = $stmt->get_result()->fetch_assoc();
  ok($u);
}

fail('UNKNOWN_FN',404);
