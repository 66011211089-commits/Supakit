<?php
require_once __DIR__.'/utils.php';
$fn = $_GET['fn'] ?? 'my_orders';

if ($fn==='create') {
  $pl = require_role(['buyer','admin']);
  $in = json_input();
  $product_id = intval($in['product_id'] ?? 0);
  $qty = max(1, intval($in['qty'] ?? 1));

  $stmt = $mysqli->prepare("SELECT price FROM products WHERE product_id=? AND status='approved'");
  $stmt->bind_param('i', $product_id);
  $stmt->execute();
  $row = $stmt->get_result()->fetch_assoc();
  if (!$row) fail('PRODUCT_NOT_AVAILABLE',404);

  $amount = $row['price'] * $qty;
  $stmt = $mysqli->prepare("INSERT INTO orders(product_id,buyer_id,qty,amount,status) VALUES(?,?,?,?, 'pending')");
  $stmt->bind_param('iiid', $product_id, $pl['uid'], $qty, $amount);
  $stmt->execute();
  ok(['order_id'=>$stmt->insert_id, 'amount'=>$amount]);
}

if ($fn==='my') {
  $pl = require_role(['buyer','seller','admin']);
  if ($pl['role']==='buyer') {
    $stmt = $mysqli->prepare("SELECT o.*, p.name AS product_name FROM orders o JOIN products p ON o.product_id=p.product_id WHERE o.buyer_id=? ORDER BY o.created_at DESC");
    $stmt->bind_param('i', $pl['uid']);
    $stmt->execute();
    ok($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
  } else if ($pl['role']==='admin') {
    $res = $mysqli->query("SELECT o.*, p.name AS product_name, u.name AS buyer_name FROM orders o JOIN products p ON o.product_id=p.product_id JOIN users u ON o.buyer_id=u.user_id ORDER BY o.created_at DESC");
    ok($res->fetch_all(MYSQLI_ASSOC));
  } else {
    // seller: orders for their products
    $stmt = $mysqli->prepare("SELECT o.*, p.name AS product_name FROM orders o JOIN products p ON o.product_id=p.product_id WHERE p.seller_id=? ORDER BY o.created_at DESC");
    $stmt->bind_param('i', $pl['uid']);
    $stmt->execute();
    ok($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
  }
}

if ($fn==='update_status') {
  require_role(['admin']);
  $in = json_input();
  $order_id = intval($in['order_id'] ?? 0);
  $status = $in['status'] ?? 'paid';
  $stmt = $mysqli->prepare("UPDATE orders SET status=? WHERE order_id=?");
  $stmt->bind_param('si', $status,$order_id);
  $stmt->execute();
  ok(['updated'=>$stmt->affected_rows]);
}

fail('UNKNOWN_FN',404);
