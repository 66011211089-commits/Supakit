<?php
require_once __DIR__.'/utils.php';
$fn = $_GET['fn'] ?? 'list';

if ($fn==='list') {
  $res = $mysqli->query("SELECT category_id,name FROM categories ORDER BY name");
  $rows = $res->fetch_all(MYSQLI_ASSOC);
  ok($rows);
}

if ($fn==='create') {
  require_role(['admin']);
  $in = json_input();
  $name = trim($in['name'] ?? '');
  if (!$name) fail('NAME_REQUIRED');
  $stmt = $mysqli->prepare("INSERT INTO categories(name) VALUES(?)");
  $stmt->bind_param('s', $name);
  $stmt->execute();
  ok(['category_id'=>$stmt->insert_id]);
}

fail('UNKNOWN_FN',404);
