<?php
// api/users.php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';

$fn = $_GET['fn'] ?? '';

function out($arr, $code=200){
  http_response_code($code);
  echo json_encode($arr, JSON_UNESCAPED_UNICODE);
  exit;
}

if ($fn === 'register') {
  $raw = file_get_contents('php://input');
  $b = json_decode($raw, true);
  if (!is_array($b)) out(['ok'=>false,'message'=>'Invalid JSON'], 400);

  $name = trim($b['name'] ?? '');
  $email = trim($b['email'] ?? '');
  $password = $b['password'] ?? '';

  if ($name==='' || $email==='' || $password==='') {
    out(['ok'=>false,'message'=>'กรอกข้อมูลให้ครบ'], 400);
  }

  try {
    // กันอีเมลซ้ำ
    $st = $conn->prepare("SELECT 1 FROM users WHERE email = ? LIMIT 1");
    $st->execute([$email]);
    if ($st->fetch()) out(['ok'=>false,'message'=>'อีเมลนี้ถูกใช้แล้ว'], 409);

    $hash = password_hash($password, PASSWORD_DEFAULT);

    // ปรับชื่อคอลัมน์ให้ตรงกับตารางของนาย (name,email,password_hash,role,created_at)
    $sql = "INSERT INTO users (name, email, password_hash, role, created_at)
            VALUES (?, ?, ?, 'seller', NOW())";
    $st = $conn->prepare($sql);
    $st->execute([$name, $email, $hash]);

    $id = (int)$conn->lastInsertId(); // ถ้าคีย์ชื่อ user_id ก็ยังได้ค่าเหมือนกัน
    $token = bin2hex(random_bytes(16));

    out(['ok'=>true, 'data'=>['id'=>$id, 'name'=>$name, 'email'=>$email, 'token'=>$token]]);
  } catch (Throwable $e) {
    out(['ok'=>false,'message'=>$e->getMessage()], 500);
  }
}

if ($fn === 'login') {
  $raw = file_get_contents('php://input');
  $b = json_decode($raw, true);
  if (!is_array($b)) out(['ok'=>false,'message'=>'Invalid JSON'], 400);

  $email = trim($b['email'] ?? '');
  $password = $b['password'] ?? '';

  if ($email==='' || $password==='') {
    out(['ok'=>false,'message'=>'กรอกข้อมูลให้ครบ'], 400);
  }

  try {
    // รองรับทั้งคีย์ id และ user_id
    $sql = "SELECT COALESCE(id, user_id) AS id, name, email, password_hash
            FROM users WHERE email = ? LIMIT 1";
    $st = $conn->prepare($sql);
    $st->execute([$email]);
    $u = $st->fetch();

    if (!$u) out(['ok'=>false,'message'=>'ไม่พบบัญชีนี้'], 404);
    if (!password_verify($password, $u['password_hash'])) {
      out(['ok'=>false,'message'=>'รหัสผ่านไม่ถูกต้อง'], 401);
    }

    $token = bin2hex(random_bytes(16));
    out(['ok'=>true, 'data'=>[
      'id'=>(int)$u['id'],
      'name'=>$u['name'],
      'email'=>$u['email'],
      'token'=>$token
    ]]);
  } catch (Throwable $e) {
    out(['ok'=>false,'message'=>$e->getMessage()], 500);
  }
}

out(['ok'=>false,'message'=>'Unknown function'], 404);
