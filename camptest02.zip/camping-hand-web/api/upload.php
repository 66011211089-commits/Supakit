<?php
require_once __DIR__.'/utils.php';
$pl = require_role(['seller','admin']);

$maxMb = intval(getenv('MAX_UPLOAD_MB') ?: 4);
$dir = __DIR__ . '/../uploads/';
if (!is_dir($dir)) { mkdir($dir, 0775, true); }

if (!isset($_FILES['file'])) fail('NO_FILE');
$ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
$ext = strtolower(preg_replace('/[^a-z0-9]/','', $ext));
if (!in_array($ext, ['jpg','jpeg','png','webp'])) fail('BAD_EXT');
if ($_FILES['file']['size'] > $maxMb*1024*1024) fail('TOO_LARGE');

$fname = uniqid('img_', true) . '.' . $ext;
$dest = $dir . $fname;
if (!move_uploaded_file($_FILES['file']['tmp_name'], $dest)) fail('MOVE_FAIL',500);

$url = '/uploads/' . $fname;
ok(['url'=>$url]);
