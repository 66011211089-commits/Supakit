<?php
// api/utils.php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=utf-8');

// CORS
$allow = getenv('APP_ALLOW_ORIGINS') ?: '*, http://localhost:8080';
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS');
header('Access-Control-Allow-Headers: Content-Type,Authorization');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

function json_input() {
  $raw = file_get_contents('php://input');
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

function ok($data) { echo json_encode(['ok'=>true,'data'=>$data]); exit; }
function fail($msg, $code=400, $extra=[]) {
  http_response_code($code);
  echo json_encode(array_merge(['ok'=>false,'error'=>$msg], $extra));
  exit;
}

// very basic token (NOT JWT). For demo only.
function sign_token($user) {
  $secret = 'demo-secret';
  $payload = base64_encode(json_encode([
    'uid'=>$user['user_id'], 'role'=>$user['role'], 'exp'=> time()+86400*3
  ]));
  $sig = hash_hmac('sha256', $payload, $secret);
  return $payload.'.'.$sig;
}
function read_token() {
  $hdr = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
  if (!preg_match('/Bearer\s+(.*)/i', $hdr, $m)) return null;
  $token = $m[1];
  $parts = explode('.', $token);
  if (count($parts) != 2) return null;
  [$payload,$sig] = $parts;
  $calc = hash_hmac('sha256', $payload, 'demo-secret');
  if (!hash_equals($calc, $sig)) return null;
  $pl = json_decode(base64_decode($payload), true);
  if (!$pl || ($pl['exp']??0) < time()) return null;
  return $pl;
}

function require_role($roles) {
  $pl = read_token();
  if (!$pl) fail('UNAUTHORIZED', 401);
  if (!in_array($pl['role'], (array)$roles)) fail('FORBIDDEN', 403);
  return $pl;
}

?>
