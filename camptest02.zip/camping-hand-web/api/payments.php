<?php
require_once __DIR__.'/utils.php';
$fn = $_GET['fn'] ?? 'create';

if ($fn==='create') {
  $pl = require_role(['buyer','admin']);
  $in = json_input();
  $order_id = intval($in['order_id'] ?? 0);
  $amount = floatval($in['amount'] ?? 0);
  $method = in_array(($in['method'] ?? 'qr'), ['qr','bank','cod','other']) ? $in['method'] : 'qr';
  if ($amount<=0) fail('INVALID_AMOUNT');

  $stmt = $mysqli->prepare("INSERT INTO payments(order_id, method, amount) VALUES(?,?,?)");
  $stmt->bind_param('isd', $order_id, $method, $amount);
  $stmt->execute();

  // mark order paid
  $stmt2 = $mysqli->prepare("UPDATE orders SET status='paid' WHERE order_id=? AND status='pending'");
  $stmt2->bind_param('i', $order_id);
  $stmt2->execute();

  ok(['payment_id'=>$stmt->insert_id]);
}

fail('UNKNOWN_FN',404);
