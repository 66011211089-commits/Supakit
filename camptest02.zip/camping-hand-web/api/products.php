<?php
// api/products.php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';

$fn = $_GET['fn'] ?? '';

if ($fn === 'create') {
  // Expect JSON body
  $raw = file_get_contents('php://input');
  $body = json_decode($raw, true);
  if (!is_array($body)) {
    echo json_encode(['ok'=>false, 'message'=>'Invalid JSON body']);
    exit;
  }

  $name        = trim($body['name'] ?? '');
  $price       = (int)($body['price'] ?? 0);
  $category_id = (int)($body['category_id'] ?? 0);
  $condition   = $body['condition'] ?? 'B';
  $description = $body['description'] ?? '';
  $image       = $body['image'] ?? '';

  // Derive seller_id (temporary strategy)
  // If client sends X-Seller-Id header use it, else default to 1
  $seller_id = 1;
  foreach (getallheaders() as $k=>$v) {
    if (strtolower($k) === 'x-seller-id') {
      $seller_id = (int)$v;
      break;
    }
  }

  if ($name === '' || $price <= 0) {
    echo json_encode(['ok'=>false, 'message'=>'กรอกชื่อสินค้าและราคาให้ครบ']);
    exit;
  }

  try {
    $sql = "INSERT INTO products (name, price, category_id, `condition`, description, image, status, seller_id)
            VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)";
    $stmt = $conn->prepare($sql);
    $ok = $stmt->execute([$name, $price, $category_id, $condition, $description, $image, $seller_id]);
    echo json_encode(['ok'=>$ok, 'message'=>$ok ? 'ส่งเสนอขายเรียบร้อย' : 'บันทึกไม่สำเร็จ']);
  } catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false, 'message'=>$e->getMessage()]);
  }
  exit;
}

// Default: not found
http_response_code(404);
echo json_encode(['ok'=>false, 'message'=>'Unknown function']);
