<?php
// api/categories.php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';

$fn = $_GET['fn'] ?? 'list';

if ($fn === 'list') {
  try {
    // ปรับให้ return เป็น id/name ที่ JS ใช้ได้ทันที
    $sql = "SELECT category_id AS id, name FROM categories ORDER BY name";
    $st  = $conn->query($sql);
    $rows = $st->fetchAll();
    echo json_encode(['ok' => true, 'data' => $rows], JSON_UNESCAPED_UNICODE);
  } catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => $e->getMessage()]);
  }
  exit;
}

http_response_code(404);
echo json_encode(['ok'=>false,'message'=>'Unknown function']);
