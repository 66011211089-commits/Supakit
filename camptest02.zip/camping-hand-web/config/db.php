<?php
// config/db.php - robust .env loader
header('Content-Type: application/json; charset=utf-8');

$root = dirname(__DIR__);
$candidates = [
  $root.'/.env',          // <project>/.env  ← ที่แนะนำ
  __DIR__.'/.env',        // เผื่อวางใน /config
  $root.'/.env.local',    // เผื่อไฟล์สำรอง
];

$envPath = null;
foreach ($candidates as $p) {
  if (file_exists($p)) { $envPath = $p; break; }
}
$env = [];
if ($envPath) {
  $env = parse_ini_file($envPath, false, INI_SCANNER_TYPED);
}

$host = $env['DB_HOST'] ?? '127.0.0.1';
$db   = $env['DB_NAME'] ?? 'camping_hand';
$user = $env['DB_USER'] ?? 'root';
$pass = $env['DB_PASS'] ?? '';

try {
  $dsn = "mysql:host={$host};dbname={$db};charset=utf8";
  $conn = new PDO($dsn, $user, $pass, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['ok'=>false, 'message'=>'DB connect failed: '.$e->getMessage()]);
  exit;
}
