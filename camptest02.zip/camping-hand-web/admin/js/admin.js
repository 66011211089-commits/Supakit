// admin/js/admin.js
async function api(path, opt={}){
  const token = localStorage.getItem('admintoken');
  opt.headers = Object.assign({'Content-Type':'application/json','Authorization':'Bearer '+(token||'')}, opt.headers||{});
  const res = await fetch(path, opt);
  return res.json();
}

if(location.pathname.endsWith('dashboard.html')){
  (async ()=>{
    // Pending count
    const r = await fetch('/api/products.php?fn=list'); // approved only, mock pending via admin page
    const j = await r.json();
    document.getElementById('pending').textContent = '—';
    document.getElementById('orders').textContent = '—';
    document.getElementById('sales').textContent = '฿' + (j.data?.reduce((a,c)=>a+Number(c.price||0),0)||0);
  })();
}

if(location.pathname.endsWith('products.html')){
  (async ()=>{
    // Load all including pending (admin view)
    const raw = await fetch('/api/products.php?fn=list');
    const j = await raw.json();
    const list = document.getElementById('list');
    (j.data||[]).forEach(p=>{
      const el = document.createElement('div');
      el.className='bg-[#0f1b28] rounded-2xl p-4 flex gap-4';
      el.innerHTML=`<img src="${p.image||''}" class="w-28 h-28 object-cover rounded-xl border border-white/10"/>
        <div class="flex-1">
          <div class="font-semibold">${p.name}</div>
          <div class="text-white/60 text-sm">${p.category_name||''} • สภาพ ${p.condition||'-'}</div>
          <div class="mt-1">฿${Number(p.price||0).toFixed(2)}</div>
          <div class="mt-2 text-white/60 text-sm">สถานะ: ${p.status}</div>
          <div class="mt-3 space-x-2">
            <button class="px-3 py-1 rounded-xl bg-[#1f8a70]" data-s="approved">อนุมัติ</button>
            <button class="px-3 py-1 rounded-xl bg-[#ffd84d] text-[#0a1622]" data-s="rejected">ปฏิเสธ</button>
          </div>
        </div>`;
      el.querySelectorAll('button').forEach(btn=>btn.addEventListener('click', async ()=>{
        await api('/api/products.php?fn=update_status', {method:'POST', body: JSON.stringify({product_id:p.product_id, status: btn.dataset.s})});
        btn.closest('div.bg-[#0f1b28]').style.opacity=.5;
      }));
      list.appendChild(el);
    });
  })();
}

if(location.pathname.endsWith('orders.html')){
  (async ()=>{
    const j = await api('/api/orders.php?fn=my');
    const tbody = document.getElementById('tbody');
    (j.data||[]).forEach(o=>{
      const tr = document.createElement('tr');
      tr.innerHTML = `<td class="p-2">${o.order_id}</td>
        <td class="p-2">${o.product_name}</td>
        <td class="p-2">${o.buyer_name||'-'}</td>
        <td class="p-2">${o.qty}</td>
        <td class="p-2">฿${Number(o.amount).toFixed(2)}</td>
        <td class="p-2">${o.status}</td>
        <td class="p-2">
          <select class="p-1 rounded bg-[#0a1622] border border-white/10">
            <option ${o.status==='paid'?'selected':''}>paid</option>
            <option ${o.status==='shipped'?'selected':''}>shipped</option>
            <option ${o.status==='delivered'?'selected':''}>delivered</option>
            <option ${o.status==='cancelled'?'selected':''}>cancelled</option>
          </select>
          <button class="ml-2 px-3 py-1 rounded-xl bg-[#1f8a70]">บันทึก</button>
        </td>`;
      const sel = tr.querySelector('select');
      tr.querySelector('button').addEventListener('click', async ()=>{
        await api('/api/orders.php?fn=update_status', {method:'POST', body: JSON.stringify({order_id:o.order_id, status: sel.value})});
        tr.style.opacity=.5;
      });
      tbody.appendChild(tr);
    });
  })();
}
