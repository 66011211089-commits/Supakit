// seller/js/sell.js
// โหลดหมวดหมู่ + ส่งฟอร์มเสนอขาย (เฉพาะส่วนที่จำเป็น)

const CAT_URL = '/api/categories.php?fn=list'; // ใช้ absolute path

async function loadCategories() {
  const sel = document.getElementById('category');
  if (!sel) return;

  sel.innerHTML = '<option value="">กำลังโหลด...</option>';

  try {
    const res = await fetch(CAT_URL, { cache: 'no-store' });
    if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
    const j = await res.json();
    if (!j.ok || !Array.isArray(j.data)) throw new Error(j.message || 'bad response');

    sel.innerHTML = '';
    j.data.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;         // map กับ API (categories.php)
      opt.textContent = c.name; // map กับ API (categories.php)
      sel.appendChild(opt);
    });

    if (sel.options.length === 0) {
      sel.innerHTML = '<option value="">ยังไม่มีหมวดหมู่</option>';
    }
  } catch (e) {
    console.error('loadCategories:', e);
    sel.innerHTML = '<option value="">โหลดหมวดหมู่ไม่สำเร็จ</option>';
  }
}

document.addEventListener('DOMContentLoaded', loadCategories);

/* ===== (ถ้ามีปุ่มส่งฟอร์มอยู่แล้ว ส่วนนี้คงไว้ได้) =====
document.getElementById('sell-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  // ... โค้ดส่งเสนอขายของโปรเจกต์เดิม ...
});
*/
