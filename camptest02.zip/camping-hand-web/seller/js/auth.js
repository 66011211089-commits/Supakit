// seller/js/auth.js

const loginTab = document.getElementById("tab-login");
const registerTab = document.getElementById("tab-register");
const formLogin = document.getElementById("form-login");
const formRegister = document.getElementById("form-register");

loginTab.addEventListener("click", () => {
  loginTab.className = "py-2 rounded-lg bg-emerald-600";
  registerTab.className = "py-2 rounded-lg bg-slate-700";
  formLogin.classList.remove("hidden");
  formRegister.classList.add("hidden");
});

registerTab.addEventListener("click", () => {
  registerTab.className = "py-2 rounded-lg bg-emerald-600";
  loginTab.className = "py-2 rounded-lg bg-slate-700";
  formRegister.classList.remove("hidden");
  formLogin.classList.add("hidden");
});

formLogin.addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("login-email").value.trim();
  const password = document.getElementById("login-password").value;
  try {
    const res = await fetch("../api/users.php?fn=login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const json = await res.json();
    if (!json.ok) throw new Error(json.message || "เข้าสู่ระบบไม่สำเร็จ");

    // save localStorage for seller
    localStorage.setItem("sellertoken", json.data.token);
    localStorage.setItem("sellerName", json.data.name);
    localStorage.setItem("sellerId", String(json.data.id));

    alert("เข้าสู่ระบบสำเร็จ!");
    // กลับไปหน้า seller หรือ sell page
    window.location.href = "./sell.html";
  } catch (err) {
    alert("❌ " + (err.message || "เกิดข้อผิดพลาด"));
    console.error(err);
  }
});

formRegister.addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = document.getElementById("reg-name").value.trim();
  const email = document.getElementById("reg-email").value.trim();
  const password = document.getElementById("reg-password").value;

  try {
    const res = await fetch("../api/users.php?fn=register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    });
    const json = await res.json();
    if (!json.ok) throw new Error(json.message || "สมัครสมาชิกไม่สำเร็จ");

    // auto login after register
    localStorage.setItem("sellertoken", json.data.token);
    localStorage.setItem("sellerName", json.data.name);
    localStorage.setItem("sellerId", String(json.data.id));

    alert("สมัครสมาชิกสำเร็จ! กำลังพาไปหน้าเสนอขาย");
    window.location.href = "./sell.html";
  } catch (err) {
    alert("❌ " + (err.message || "เกิดข้อผิดพลาด"));
    console.error(err);
  }
});
