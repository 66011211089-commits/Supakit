
-- Camping Hand schema (MySQL 8.x)

CREATE DATABASE IF NOT EXISTS camping_hand CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE camping_hand;

-- Users: buyer/seller/admin
CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  role ENUM('buyer','seller','admin') NOT NULL DEFAULT 'buyer',
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories
CREATE TABLE IF NOT EXISTS categories (
  category_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products (posted by a seller, approved by admin)
CREATE TABLE IF NOT EXISTS products (
  product_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  description TEXT,
  category_id INT NOT NULL,
  seller_id INT NOT NULL,
  `condition` ENUM('A','B','C','D') DEFAULT 'B', -- A best
  price DECIMAL(12,2) NOT NULL,
  image VARCHAR(255),
  status ENUM('pending','approved','rejected','sold','archived') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(category_id),
  FOREIGN KEY (seller_id) REFERENCES users(user_id)
);

-- Inventory (1-0..1 to product)
CREATE TABLE IF NOT EXISTS inventory (
  product_id INT PRIMARY KEY,
  stock_qty INT NOT NULL DEFAULT 1,
  FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE
);

-- Orders (simple one-product order for clarity)
CREATE TABLE IF NOT EXISTS orders (
  order_id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  buyer_id INT NOT NULL,
  qty INT NOT NULL DEFAULT 1,
  amount DECIMAL(12,2) NOT NULL,
  status ENUM('pending','paid','shipped','delivered','cancelled') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(product_id),
  FOREIGN KEY (buyer_id) REFERENCES users(user_id)
);

-- Payments (allow multiple payments per order)
CREATE TABLE IF NOT EXISTS payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  method ENUM('qr','bank','cod','other') DEFAULT 'qr',
  amount DECIMAL(12,2) NOT NULL,
  payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

-- Seed admin
INSERT INTO users (name, email, role, password_hash)
VALUES ('Admin', 'admin@camping.hand', 'admin', '$2y$10$NQ5sA1UOZ4w4p0R9pB0t8eO1z3vQv6sS8Xx4yQ4RyXmM5d0b8i0bm'); -- password: admin123

-- Sample categories
INSERT INTO categories (name) VALUES ('เต็นท์'),('เตา / อุปกรณ์ทำอาหาร'),('เฟอร์นิเจอร์แคมป์'),('กระเป๋า / เป้'),('อื่น ๆ');
