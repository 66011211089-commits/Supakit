# Camping Hand — Web (HTML/JS/PHP + MySQL)

A working e‑commerce scaffold for second‑hand camping gear. Frontend (HTML + Tailwind + JS) styled to a navy–green–gold theme, backend in PHP with MySQL (mysqli).

## Structure
```
camping-hand/
├─ README.md
├─ database.sql
├─ config/
│  ├─ env.sample
│  └─ db.php
├─ api/
│  ├─ utils.php
│  ├─ auth.php        # register/login/profile
│  ├─ categories.php  # list/create categories
│  ├─ products.php    # CRUD products, list, detail, search
│  ├─ upload.php      # image upload
│  ├─ orders.php      # create order, list by user/admin, update status
│  └─ payments.php    # record payment (mock)
├─ admin/
│  ├─ login.html
│  ├─ dashboard.html
│  ├─ products.html
│  ├─ orders.html
│  └─ js/admin.js
├─ customer/
│  ├─ index.html
│  ├─ product.html
│  ├─ cart.html
│  ├─ checkout.html
│  ├─ orders.html
│  ├─ js/shop.js
│  └─ css/theme.css
└─ uploads/
```
## Quick start
1. Create MySQL DB and import `database.sql`.
2. Copy `config/env.sample` to `config/.env` and change credentials.
3. Serve the folder: `php -S 0.0.0.0:8080 -t path/to/camping-hand`
4. Visit:
   - Customer: `/customer/index.html`
   - Admin: `/admin/login.html` (user: `admin@camping.hand`, pass: `admin123`—created by seed)

> Security note: This is a learning scaffold. Use proper JWT/session, CSRF protection, input validation, and hardened upload limits before production.
