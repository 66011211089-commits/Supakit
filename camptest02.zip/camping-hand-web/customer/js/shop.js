// customer/js/shop.js
const $ = (q, el=document)=>el.querySelector(q);
const apiBase = '/api';

function cartGet(){ try{return JSON.parse(localStorage.getItem('cart')||'[]')}catch(e){return []} }
function cartSet(v){ localStorage.setItem('cart', JSON.stringify(v)); }
function cartAdd(item){ const c=cartGet(); c.push(item); cartSet(c); }

async function listProducts(q=''){
  const u = q ? `/api/products.php?fn=list&q=` + encodeURIComponent(q) : '/api/products.php?fn=list';
  const res = await fetch(u); const j = await res.json(); return j.data||[];
}

function price(x){ return '฿'+Number(x||0).toFixed(2); }

if(location.pathname.endsWith('/index.html') || location.pathname.endsWith('/customer/') || location.pathname.endsWith('/customer')){
  (async ()=>{
    const grid = $('#grid');
    async function render(q=''){
      grid.innerHTML='';
      const items = await listProducts(q);
      items.forEach(p=>{
        const el = document.createElement('div');
        el.className='card';
        el.innerHTML = `<img src="${p.image||''}" class="w-full h-40 object-cover rounded-xl border border-white/10"/>
          <div class="mt-3 font-semibold">${p.name}</div>
          <div class="text-white/60 text-sm">${p.category_name||''} • สภาพ ${p.condition||'-'}</div>
          <div class="mt-1">${price(p.price)}</div>
          <div class="mt-3 flex gap-2">
            <a class="px-3 py-2 rounded-xl bg-[var(--accent)]" href="product.html?id=${p.product_id}">รายละเอียด</a>
            <button class="px-3 py-2 rounded-xl bg-[var(--accent-2)] text-[#0a1622]">ใส่ตะกร้า</button>
          </div>`;
        el.querySelector('button').addEventListener('click', ()=>{
          cartAdd({product_id:p.product_id, name:p.name, price:p.price, qty:1});
          alert('เพิ่มลงตะกร้าแล้ว');
        });
        grid.appendChild(el);
      });
    }
    $('#search').addEventListener('click', ()=>render($('#q').value.trim()));
    render();
  })();
}

if(location.pathname.endsWith('/product.html')){
  (async ()=>{
    const id = new URLSearchParams(location.search).get('id');
    const res = await fetch(`/api/products.php?fn=detail&id=${id}`);
    const j = await res.json();
    const p = j.data;
    const wrap = $('#wrap');
    wrap.innerHTML = `<div class="card">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <img src="${p.image||''}" class="w-full h-64 object-cover rounded-xl border border-white/10"/>
        <div>
          <div class="text-2xl font-bold">${p.name||'-'}</div>
          <div class="mt-2 text-white/60">${p.category_name||''} • สภาพ ${p.condition||'-'}</div>
          <div class="mt-3">${price(p.price)}</div>
          <p class="mt-4 whitespace-pre-wrap">${p.description||''}</p>
          <div class="mt-6 flex gap-2">
            <button id="add" class="px-4 py-2 rounded-xl bg-[var(--accent-2)] text-[#0a1622]">ใส่ตะกร้า</button>
          </div>
        </div>
      </div>
    </div>`;
    $('#add').addEventListener('click', ()=>{
      cartAdd({product_id:p.product_id, name:p.name, price:p.price, qty:1});
      alert('เพิ่มลงตะกร้าแล้ว');
    });
  })();
}

if(location.pathname.endsWith('/cart.html')){
  (async ()=>{
    const list = $('#cart'); const totalEl = $('#total');
    function render(){
      list.innerHTML='';
      let total=0;
      const c = cartGet();
      c.forEach((it, idx)=>{
        total += Number(it.price)*it.qty;
        const div = document.createElement('div');
        div.className='card flex items-center justify-between';
        div.innerHTML = `<div>
            <div class="font-semibold">${it.name}</div>
            <div class="text-white/60 text-sm">${price(it.price)} × ${it.qty}</div>
          </div>
          <div class="space-x-2">
            <button class="px-3 py-2 rounded-xl bg-[var(--accent)]" data-idx="${idx}" data-a="inc">+</button>
            <button class="px-3 py-2 rounded-xl bg-[var(--accent)]" data-idx="${idx}" data-a="dec">-</button>
            <button class="px-3 py-2 rounded-xl bg-red-600" data-idx="${idx}" data-a="del">ลบ</button>
          </div>`;
        list.appendChild(div);
      });
      totalEl.textContent = price(total);
    }
    list.addEventListener('click', (e)=>{
      const btn = e.target.closest('button'); if(!btn) return;
      const idx = Number(btn.dataset.idx); const a = btn.dataset.a;
      const c = cartGet();
      if(a==='inc') c[idx].qty++;
      if(a==='dec') c[idx].qty = Math.max(1, c[idx].qty-1);
      if(a==='del') c.splice(idx,1);
      cartSet(c); render();
    });
    render();
  })();
}

if(location.pathname.endsWith('/checkout.html')){
  (async ()=>{
    $('#pay').addEventListener('click', async ()=>{
      // Create order for first item (demo)
      const c = cartGet();
      if(!c.length){ alert('ตะกร้าว่าง'); return; }
      const first = c[0];
      // Demo: call order create with a fake buyer token (not secure)
      // In real app you'd login to get buyer token. Here we skip auth for brevity.
      const res = await fetch('/api/orders.php?fn=create',{method:'POST', headers:{'Content-Type':'application/json','Authorization':'Bearer eyJkZW1vIjp0cnVlfQ==.dummy'}, body: JSON.stringify({product_id:first.product_id, qty:first.qty})});
      const j = await res.json();
      if(!j.ok){ alert(j.error||'สร้างคำสั่งซื้อไม่สำเร็จ'); return; }
      await fetch('/api/payments.php?fn=create',{method:'POST', headers:{'Content-Type':'application/json','Authorization':'Bearer eyJkZW1vIjp0cnVlfQ==.dummy'}, body: JSON.stringify({order_id:j.data.order_id, amount:j.data.amount, method:'qr'})});
      alert('บันทึกการชำระเงินแล้ว (จำลอง)'); cartSet([]); location.href='orders.html';
    });
  })();
}

if(location.pathname.endsWith('/orders.html')){
  (async ()=>{
    const box = $('#orders');
    const res = await fetch('/api/orders.php?fn=my', {headers:{'Authorization':'Bearer eyJkZW1vIjp0cnVlfQ==.dummy'}});
    const j = await res.json();
    (j.data||[]).forEach(o=>{
      const el = document.createElement('div');
      el.className='card';
      el.innerHTML = `<div class="flex items-center justify-between">
        <div>#${o.order_id} • ${o.product_name}</div>
        <div>${price(o.amount)} • <span class="tag">${o.status}</span></div>
      </div>`;
      box.appendChild(el);
    });
  })();
}
