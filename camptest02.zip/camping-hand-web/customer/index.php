<?php
// Redirect root to customer home
header("Location: customer/index.html");
exit();
