# Camping Hand — PHP + MySQL Starter (Shopee-like)

Starter for an e-commerce app with Login/Register + Role tabs (Admin/User).
See `schema.sql` and `config/db.php`. Serve the `public/` folder.
