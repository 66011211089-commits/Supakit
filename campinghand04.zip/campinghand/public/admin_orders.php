<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
require_role('admin');

// ดึงข้อมูลคำสั่งซื้อทั้งหมด
$stmt = $pdo->query("SELECT * FROM orders ORDER BY created_at DESC");
$orders = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <title>แผงจัดการคำสั่งซื้อ | Camping Hand</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
</head>
<body class="bg-gray-50 text-gray-800">
  <header class="bg-white shadow-sm py-4 px-6 flex justify-between items-center">
    <h1 class="text-xl font-bold text-orange-600">Camping Hand <span class="text-sm text-red-500 bg-red-50 px-2 py-1 rounded-lg">Admin</span></h1>
    <nav>
      <a href="admin.php" class="text-gray-600 hover:text-orange-600 mr-4">แผงควบคุม</a>
      <a href="logout.php" class="text-red-500 font-medium hover:underline">ออกจากระบบ</a>
    </nav>
  </header>

  <main class="max-w-5xl mx-auto mt-10 bg-white shadow-md rounded-xl p-6">
    <h2 class="text-2xl font-bold mb-6 flex items-center">
      🧾 รายการคำสั่งซื้อทั้งหมด
    </h2>

    <?php if (empty($orders)): ?>
      <p class="text-gray-500">ยังไม่มีคำสั่งซื้อในระบบ</p>
    <?php else: ?>
      <table class="min-w-full border-collapse border border-gray-200">
        <thead class="bg-orange-100">
          <tr>
            <th class="border border-gray-200 py-2 px-3">#</th>
            <th class="border border-gray-200 py-2 px-3 text-left">ยอดรวม</th>
            <th class="border border-gray-200 py-2 px-3 text-left">วันที่สั่งซื้อ</th>
            <th class="border border-gray-200 py-2 px-3 text-center">สถานะ</th>
            <th class="border border-gray-200 py-2 px-3 text-center">การจัดการ</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($orders as $order): ?>
            <tr class="hover:bg-orange-50">
              <td class="border border-gray-200 py-2 px-3 text-center">#<?= htmlspecialchars($order['id']) ?></td>
              <td class="border border-gray-200 py-2 px-3"><?= number_format($order['total_price'], 2) ?> ฿</td>
              <td class="border border-gray-200 py-2 px-3"><?= htmlspecialchars($order['created_at']) ?></td>
              <td class="border border-gray-200 py-2 px-3 text-center">
                <?php
                $statusClass = [
                  'pending' => 'bg-yellow-100 text-yellow-700',
                  'shipped' => 'bg-blue-100 text-blue-700',
                  'completed' => 'bg-green-100 text-green-700',
                  'cancelled' => 'bg-red-100 text-red-700'
                ];
                $status = $order['status'] ?? 'pending';
                ?>
                <span class="px-3 py-1 rounded-lg text-sm font-semibold <?= $statusClass[$status] ?? 'bg-gray-100 text-gray-700' ?>">
                  <?= ucfirst($status) ?>
                </span>
              </td>
              <td class="border border-gray-200 py-2 px-3 text-center">
                <a href="order_detail.php?id=<?= $order['id'] ?>" class="text-orange-600 hover:underline font-medium">ดูรายละเอียด</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </main>

  <footer class="text-center text-sm text-gray-500 py-6">
    © <?= date('Y') ?> Camping Hand — ระบบจัดการร้านค้า
  </footer>
</body>
</html>
