<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
require_role('admin');

// ตรวจสอบว่ามี id หรือไม่
if (!isset($_GET['id'])) {
  die("ไม่พบรหัสคำสั่งซื้อ");
}

$order_id = $_GET['id'];

// ดึงข้อมูลคำสั่งซื้อ
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch();

if (!$order) {
  die("ไม่พบคำสั่งซื้อที่ระบุ");
}

// ดึงรายการสินค้าในคำสั่งซื้อนี้
$stmtItems = $pdo->prepare("
  SELECT oi.*, p.name AS product_name, p.image AS product_image 
  FROM order_items oi
  JOIN products p ON oi.product_id = p.id
  WHERE oi.order_id = ?
");
$stmtItems->execute([$order_id]);
$items = $stmtItems->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <title>รายละเอียดคำสั่งซื้อ #<?= htmlspecialchars($order_id) ?> | Camping Hand</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
</head>
<body class="bg-gray-50 text-gray-800">
  <header class="bg-white shadow-sm py-4 px-6 flex justify-between items-center">
    <h1 class="text-xl font-bold text-orange-600">Camping Hand <span class="text-sm text-red-500 bg-red-50 px-2 py-1 rounded-lg">Admin</span></h1>
    <nav>
      <a href="admin_orders.php" class="text-gray-600 hover:text-orange-600 mr-4">← กลับไปคำสั่งซื้อทั้งหมด</a>
      <a href="logout.php" class="text-red-500 font-medium hover:underline">ออกจากระบบ</a>
    </nav>
  </header>

  <main class="max-w-4xl mx-auto mt-10 bg-white shadow-md rounded-xl p-6">
    <h2 class="text-2xl font-bold mb-6 flex items-center">
      🧾 รายละเอียดคำสั่งซื้อ #<?= htmlspecialchars($order_id) ?>
    </h2>

    <div class="mb-6">
      <p><strong>ยอดรวมทั้งหมด:</strong> <?= number_format($order['total_price'], 2) ?> ฿</p>
      <p><strong>วันที่สั่งซื้อ:</strong> <?= htmlspecialchars($order['created_at']) ?></p>
      <p><strong>สถานะ:</strong>
        <span class="px-3 py-1 rounded-lg text-sm font-semibold
          <?= match($order['status']) {
            'pending' => 'bg-yellow-100 text-yellow-700',
            'shipped' => 'bg-blue-100 text-blue-700',
            'completed' => 'bg-green-100 text-green-700',
            'cancelled' => 'bg-red-100 text-red-700',
            default => 'bg-gray-100 text-gray-700'
          } ?>">
          <?= ucfirst($order['status']) ?>
        </span>
      </p>
    </div>

    <h3 class="text-lg font-semibold mb-3">🛍️ รายการสินค้า</h3>
    <table class="min-w-full border-collapse border border-gray-200 mb-6">
      <thead class="bg-orange-100">
        <tr>
          <th class="border border-gray-200 py-2 px-3">รูปภาพ</th>
          <th class="border border-gray-200 py-2 px-3 text-left">สินค้า</th>
          <th class="border border-gray-200 py-2 px-3 text-center">จำนวน</th>
          <th class="border border-gray-200 py-2 px-3 text-right">ราคา</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($items as $item): ?>
        <tr class="hover:bg-orange-50">
          <td class="border border-gray-200 py-2 px-3 text-center">
            <img src="uploads/<?= htmlspecialchars($item['product_image']) ?>" alt="Product" class="w-16 h-16 object-cover rounded-lg mx-auto">
          </td>
          <td class="border border-gray-200 py-2 px-3"><?= htmlspecialchars($item['product_name']) ?></td>
          <td class="border border-gray-200 py-2 px-3 text-center"><?= htmlspecialchars($item['quantity']) ?></td>
          <td class="border border-gray-200 py-2 px-3 text-right"><?= number_format($item['price'], 2) ?> ฿</td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <form action="update_order_status.php" method="post" class="mt-6">
      <input type="hidden" name="order_id" value="<?= htmlspecialchars($order_id) ?>">
      <label for="status" class="block mb-2 font-medium">เปลี่ยนสถานะคำสั่งซื้อ:</label>
      <select name="status" id="status" class="border border-gray-300 rounded-lg p-2 mb-4">
        <option value="pending" <?= $order['status'] == 'pending' ? 'selected' : '' ?>>รอดำเนินการ</option>
        <option value="shipped" <?= $order['status'] == 'shipped' ? 'selected' : '' ?>>จัดส่งแล้ว</option>
        <option value="completed" <?= $order['status'] == 'completed' ? 'selected' : '' ?>>เสร็จสิ้น</option>
        <option value="cancelled" <?= $order['status'] == 'cancelled' ? 'selected' : '' ?>>ยกเลิก</option>
      </select>
      <button type="submit" class="bg-orange-500 text-white px-5 py-2 rounded-lg hover:bg-orange-600">
        อัปเดตสถานะ
      </button>
    </form>
  </main>

  <footer class="text-center text-sm text-gray-500 py-6">
    © <?= date('Y') ?> Camping Hand — ระบบจัดการร้านค้า
  </footer>
</body>
</html>
