<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

define('DB_HOST','localhost');
define('DB_NAME','campinghand');
define('DB_USER','root');
define('DB_PASS','');

try {
  $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
  ]);
} catch(PDOException $e) {
  die("DB connection failed: ".htmlspecialchars($e->getMessage()));
}

$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$cart_items = [];
$total = 0;

if (!empty($cart)) {
  $ids = implode(',', array_keys($cart));
  $stmt = $pdo->query("SELECT * FROM products WHERE id IN ($ids)");
  $cart_items = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ตะกร้าสินค้า | Camping Hand</title>
</head>
<body>
<h1>ตะกร้าสินค้าของคุณ</h1>

<?php if (empty($cart_items)): ?>
<p>ยังไม่มีสินค้าในตะกร้า</p>
<?php else: ?>
<table border="1" cellpadding="8" cellspacing="0">
  <tr>
    <th>สินค้า</th>
    <th>ราคา</th>
    <th>จำนวน</th>
    <th>รวม</th>
    <th>ลบ</th>
  </tr>
  <?php foreach ($cart_items as $item): 
    $qty = $cart[$item['id']];
    $subtotal = $item['price'] * $qty;
    $total += $subtotal;

    // ✅ Fix รูปภาพให้แสดงผลได้แน่นอน
    $imgPath = $item['image'];
    if (!file_exists($imgPath)) {
        $imgPath = 'uploads/' . basename($imgPath);
    }
    if (!file_exists($imgPath)) {
        $imgPath = 'uploads/no-image.png';
    }
  ?>
  <tr>
    <td>
      <img src="<?= htmlspecialchars($imgPath) ?>" alt="<?= htmlspecialchars($item['name']) ?>" width="80" height="80" style="object-fit:cover;border-radius:10px;">
      <?= htmlspecialchars($item['name']) ?>
    </td>
    <td><?= number_format($item['price'], 2) ?> ฿</td>
    <td><?= $qty ?></td>
    <td><?= number_format($subtotal, 2) ?> ฿</td>
    <td><a href="?remove=<?= $item['id'] ?>">ลบ</a></td>
  </tr>
  <?php endforeach; ?>
</table>

<h3>รวมทั้งหมด: <?= number_format($total, 2) ?> บาท</h3>
<?php endif; ?>

</body>
</html>
