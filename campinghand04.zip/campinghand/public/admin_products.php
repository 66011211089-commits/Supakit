<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// ===== Database Connection =====
define('DB_HOST','localhost');
define('DB_NAME','campinghand');
define('DB_USER','root');
define('DB_PASS','');

try {
  $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
  ]);
} catch(PDOException $e) {
  die("DB connection failed: " . htmlspecialchars($e->getMessage()));
}

// ===== Add New Product =====
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['add_product'])) {
    $name = trim($_POST['name']);
    $price = floatval($_POST['price']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);
    $imagePath = "";

    if (!empty($_FILES['image']['name'])) {
        $targetDir = "uploads/";
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'jfif'];
        $fileExt = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));

        if (in_array($fileExt, $allowedTypes)) {
            $fileName = uniqid() . "." . $fileExt;
            $targetFile = $targetDir . $fileName;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
                $imagePath = $targetFile;
            }
        }
    }

    if ($name && $price && $category) {
        $stmt = $pdo->prepare("INSERT INTO products (name, price, category, description, image) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $price, $category, $description, $imagePath]);
        header("Location: admin_products.php");
        exit;
    }
}

// ===== Update Product =====
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['update_product'])) {
    $id = intval($_POST['id']);
    $name = trim($_POST['name']);
    $price = floatval($_POST['price']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);

    // ดึงข้อมูลเดิมมาก่อน
    $stmt = $pdo->prepare("SELECT image FROM products WHERE id=?");
    $stmt->execute([$id]);
    $old = $stmt->fetch();
    $imagePath = $old['image'];

    if (!empty($_FILES['image']['name'])) {
        $targetDir = "uploads/";
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'jfif'];
        $fileExt = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));

        if (in_array($fileExt, $allowedTypes)) {
            $fileName = uniqid() . "." . $fileExt;
            $targetFile = $targetDir . $fileName;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
                $imagePath = $targetFile;
            }
        }
    }

    $stmt = $pdo->prepare("UPDATE products SET name=?, price=?, category=?, description=?, image=? WHERE id=?");
    $stmt->execute([$name, $price, $category, $description, $imagePath, $id]);
    header("Location: admin_products.php");
    exit;
}

// ===== Delete Product =====
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $pdo->prepare("DELETE FROM products WHERE id=?")->execute([$id]);
    header("Location: admin_products.php");
    exit;
}

// ===== Fetch Products =====
$products = $pdo->query("SELECT * FROM products ORDER BY id DESC")->fetchAll();
$editProduct = null;
if (isset($_GET['edit'])) {
  $id = intval($_GET['edit']);
  $stmt = $pdo->prepare("SELECT * FROM products WHERE id=?");
  $stmt->execute([$id]);
  $editProduct = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>จัดการสินค้า | Camping Hand</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
body { font-family: 'Inter', sans-serif; background-color: #f9fafb; }
input, select, textarea { border-radius: 0.5rem; border: 1px solid #ccc; padding: 0.5rem; width: 100%; }
button:disabled { background-color: #ccc; cursor: not-allowed; }
</style>
</head>
<body>
<header class="flex justify-between items-center p-6 bg-white shadow-sm">
  <h1 class="text-xl font-bold text-gray-800">Camping Hand <span class="text-red-500 text-sm">Admin</span></h1>
  <div class="space-x-4">
    <a href="index.php" class="text-gray-600 hover:text-gray-900">กลับหน้าหลัก</a>
    <a href="logout.php" class="text-red-500 hover:underline">ออกจากระบบ</a>
  </div>
</header>

<main class="p-8 max-w-6xl mx-auto">
  <h2 class="text-2xl font-bold text-gray-700 mb-6 text-center">🛠️ จัดการสินค้า</h2>

  <!-- Add/Edit Product Form -->
  <form method="POST" enctype="multipart/form-data" class="bg-white shadow-md rounded-2xl p-6 mb-10 space-y-3">
    <h3 class="font-semibold text-gray-700 text-lg mb-3">
      <?= $editProduct ? '✏️ แก้ไขสินค้า #' . htmlspecialchars($editProduct['id']) : '➕ เพิ่มสินค้าใหม่' ?>
    </h3>
    <input type="hidden" name="id" value="<?= $editProduct['id'] ?? '' ?>">

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <input type="text" name="name" placeholder="ชื่อสินค้า" value="<?= htmlspecialchars($editProduct['name'] ?? '') ?>" required>
      <input type="number" name="price" step="0.01" placeholder="ราคา" value="<?= htmlspecialchars($editProduct['price'] ?? '') ?>" required>
      <select name="category" required>
        <option value="">-- เลือกหมวดหมู่ --</option>
        <?php
        $cats = ['เต็นท์', 'เสื้อผ้า', 'กระเป๋า', 'เครื่องมือเดินป่า', 'อื่นๆ'];
        foreach ($cats as $c) {
          $sel = ($editProduct && $editProduct['category'] == $c) ? 'selected' : '';
          echo "<option value='$c' $sel>$c</option>";
        }
        ?>
      </select>
      <input type="file" name="image" accept=".jpg,.jpeg,.png,.gif,.webp,.jfif">
    </div>
    <textarea name="description" rows="3" placeholder="รายละเอียดสินค้า" class="mt-2"><?= htmlspecialchars($editProduct['description'] ?? '') ?></textarea>

    <button type="submit" name="<?= $editProduct ? 'update_product' : 'add_product' ?>"
      class="bg-yellow-400 text-black px-5 py-2 rounded-lg font-semibold hover:bg-yellow-500 transition">
      <?= $editProduct ? 'บันทึกการแก้ไข' : 'เพิ่มสินค้า' ?>
    </button>
    <?php if ($editProduct): ?>
      <a href="admin_products.php" class="ml-2 text-gray-600 hover:underline">ยกเลิก</a>
    <?php endif; ?>
  </form>

  <!-- Product Table -->
  <div class="bg-white shadow-md rounded-2xl p-6">
    <h3 class="font-semibold text-gray-700 text-lg mb-3">📦 รายการสินค้าทั้งหมด</h3>
    <table class="w-full text-sm text-left text-gray-700">
      <thead class="bg-yellow-100 text-gray-800">
        <tr>
          <th class="px-4 py-2">รหัส</th>
          <th class="px-4 py-2">รูปภาพ</th>
          <th class="px-4 py-2">ชื่อสินค้า</th>
          <th class="px-4 py-2">หมวดหมู่</th>
          <th class="px-4 py-2">ราคา</th>
          <th class="px-4 py-2 text-center">จัดการ</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($products as $p): ?>
          <tr class="border-t hover:bg-gray-50">
            <td class="px-4 py-2">#<?= $p['id'] ?></td>
            <td class="px-4 py-2"><img src="<?= htmlspecialchars($p['image']) ?>" class="w-14 h-14 object-cover rounded"></td>
            <td class="px-4 py-2"><?= htmlspecialchars($p['name']) ?></td>
            <td class="px-4 py-2"><?= htmlspecialchars($p['category']) ?></td>
            <td class="px-4 py-2"><?= number_format($p['price'],2) ?> ฿</td>
            <td class="px-4 py-2 text-center space-x-2">
              <a href="?edit=<?= $p['id'] ?>" class="bg-blue-500 text-white px-3 py-1 rounded">แก้ไข</a>
              <a href="?delete=<?= $p['id'] ?>" onclick="return confirm('ลบสินค้านี้ใช่หรือไม่?')" class="bg-red-500 text-white px-3 py-1 rounded">ลบ</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</main>
</body>
</html>
