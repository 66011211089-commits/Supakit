<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('user');

$product_id = intval($_GET['id'] ?? 0);
if ($product_id <= 0) die('Invalid product');

$stmt = $pdo->prepare("SELECT id FROM products WHERE id = ?");
$stmt->execute([$product_id]);
if (!$stmt->fetch()) die('Product not found');

$stmt = $pdo->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?");
$stmt->execute([$_SESSION['user_id'], $product_id]);
$exist = $stmt->fetch();

if ($exist) {
    $stmt = $pdo->prepare("UPDATE cart SET quantity = quantity + 1 WHERE id = ?");
    $stmt->execute([$exist['id']]);
} else {
    $stmt = $pdo->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 1)");
    $stmt->execute([$_SESSION['user_id'], $product_id]);
}

header("Location: /cart.php");
exit;
