<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('admin'); // จำลองให้แอดมินหรือผู้ขายเท่านั้นเพิ่มสินค้าได้
require_once __DIR__ . '/../includes/csrf.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim($_POST['name']);
    $price = floatval($_POST['price']);
    $desc = trim($_POST['description']);
    $cat = intval($_POST['category_id']);
    $imgName = null;

    if (!empty($_FILES['image']['name'])) {
        $targetDir = __DIR__ . "/uploads/";
        $imgName = time() . "_" . basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], $targetDir . $imgName);
    }

    $stmt = $pdo->prepare("INSERT INTO products (name, price, description, image, category_id, user_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $price, $desc, $imgName, $cat, $_SESSION['user_id']]);

    echo "<script>alert('เพิ่มสินค้าสำเร็จ!'); window.location='products.php';</script>";
    exit;
}

$cats = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();
?>
<!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8">
  <title>เพิ่มสินค้า - Camping Hand</title>
  <link rel="stylesheet" href="/assets/styles.css">
</head>
<body>
  <header class="header">
    <div class="container nav">
      <div class="brand">Camping Hand <span class="badge">Add Product</span></div>
      <a href="/products.php">ดูสินค้าทั้งหมด</a>
    </div>
  </header>

  <main class="container" style="margin-top:24px;">
    <div class="card" style="max-width:600px;margin:0 auto;">
      <h1>เพิ่มสินค้าใหม่</h1>
      <form method="post" enctype="multipart/form-data" style="display:grid;gap:12px;">
        <?php csrf_field(); ?>
        <label class="label">ชื่อสินค้า</label>
        <input class="input" name="name" required>

        <label class="label">ราคา (บาท)</label>
        <input class="input" type="number" name="price" step="0.01" required>

        <label class="label">หมวดหมู่</label>
        <select class="input" name="category_id" required>
          <option value="">-- เลือกหมวดหมู่ --</option>
          <?php foreach ($cats as $c): ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
          <?php endforeach; ?>
        </select>

        <label class="label">คำอธิบาย</label>
        <textarea class="input" name="description" rows="4"></textarea>

        <label class="label">รูปสินค้า</label>
        <input type="file" name="image" accept="image/*">

        <button class="btn" type="submit">บันทึกสินค้า</button>
      </form>
    </div>
  </main>
</body>
</html>
