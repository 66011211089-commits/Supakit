document.addEventListener('DOMContentLoaded',()=>{
  const tabs=document.querySelectorAll('[data-role-tab]'); const roleInput=document.querySelector('input[name="role"]');
  tabs.forEach(t=>t.addEventListener('click',()=>{ tabs.forEach(x=>x.classList.remove('active')); t.classList.add('active'); const r=t.getAttribute('data-role-tab'); if(roleInput) roleInput.value=r; }));
});