<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
$err=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
  verify_csrf();
  $email=trim($_POST['email']??''); $password=$_POST['password']??''; $role=$_POST['role']??'user';
  if($email===''||$password===''){ $err='กรอกอีเมลและรหัสผ่านให้ครบ'; }
  else{
    $stmt=$pdo->prepare('SELECT * FROM users WHERE email=? AND role=? LIMIT 1'); $stmt->execute([$email,$role]); $u=$stmt->fetch();
    if($u && password_verify($password,$u['password_hash'])){ login_user($u); header('Location: '.($role === 'admin' ? '/admin.php' : '/user.php'));
 exit; }
    else{ $err='อีเมล/รหัสผ่าน หรือ บทบาท ไม่ถูกต้อง'; }
  }
}
?><!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Camping Hand — Login</title><link rel="stylesheet" href="/assets/styles.css"><script defer src="/assets/app.js"></script></head>
<body><header class="header"><div class="container nav"><div class="brand">Camping Hand <span class="badge">Beta</span></div><div style="margin-left:auto"></div><a href="/register.php">สมัครสมาชิก</a></div></header>
<main class="container" style="margin-top:24px;"><div class="card" style="max-width:560px; margin:0 auto;"><h1>เข้าสู่ระบบ</h1><div class="helper">เลือกระหว่าง <b>Admin</b> หรือ <b>User</b> ให้ตรงกับสถานะบัญชีของคุณ</div>
<div class="tabs" role="tablist"><button class="tab active" data-role-tab="user">User</button><button class="tab" data-role-tab="admin">Admin</button></div>
<?php if($err): ?><div class="error"><?= htmlspecialchars($err) ?></div><?php endif; ?>
<form method="post" action="/login.php" style="display:grid; gap:12px;"><?php csrf_field(); ?><input type="hidden" name="role" value="user" />
<label class="label">อีเมล</label><input class="input" type="email" name="email" placeholder="you@example.com" required>
<label class="label">รหัสผ่าน</label><input class="input" type="password" name="password" placeholder="••••••••" required>
<button class="btn" type="submit">เข้าสู่ระบบ</button><div class="helper">ยังไม่มีบัญชี? <a href="/register.php">สมัครสมาชิก</a></div></form></div><div class="footer">© Camping Hand</div></main></body></html>
