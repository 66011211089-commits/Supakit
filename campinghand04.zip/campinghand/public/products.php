<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

define('DB_HOST', 'localhost');
define('DB_NAME', 'campinghand');
define('DB_USER', 'root');
define('DB_PASS', '');

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");
$products = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>รายการสินค้า | Camping Hand</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
body { font-family: 'Inter', sans-serif; background: #f9fafb; }
.card { transition: all .2s; }
.card:hover { transform: translateY(-5px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
</style>
</head>
<body class="min-h-screen">
<header class="flex justify-between items-center p-6 shadow-sm bg-white">
  <h1 class="text-xl font-bold text-gray-800">Camping Hand <span class="text-red-500 text-sm font-medium">User</span></h1>
  <a href="logout.php" class="text-red-500 hover:underline">ออกจากระบบ</a>
</header>

<main class="p-6 max-w-6xl mx-auto">
  <h2 class="text-2xl font-bold mb-6">รายการสินค้า</h2>

  <?php if (count($products) > 0): ?>
  <div class="grid md:grid-cols-4 sm:grid-cols-2 gap-6">
    <?php foreach ($products as $product): ?>
    <div class="card bg-white rounded-xl shadow-md overflow-hidden">
      <?php
      $imgPath = htmlspecialchars($product['image']);
      // ตรวจสอบว่าไฟล์มีอยู่จริงไหม (แก้ปัญหา path)
      if (!file_exists(__DIR__ . '/' . $imgPath)) {
          $imgPath = 'uploads/' . basename($product['image']); 
      }
      ?>
      <img src="<?= $imgPath ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-48 object-cover bg-gray-100">
      <div class="p-4">
        <h3 class="font-semibold text-gray-800 truncate"><?= htmlspecialchars($product['name']) ?></h3>
        <p class="text-gray-500 text-sm"><?= htmlspecialchars($product['category'] ?? '-') ?></p>
        <p class="text-red-600 font-semibold mt-1"><?= number_format($product['price'], 2) ?> บาท</p>
        <a href="product_detail.php?id=<?= $product['id'] ?>" class="block mt-3 bg-orange-500 text-white text-center py-2 rounded-lg hover:bg-orange-600">ดูรายละเอียด</a>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php else: ?>
  <p class="text-center text-gray-400">ยังไม่มีสินค้าในระบบ</p>
  <?php endif; ?>
</main>
</body>
</html>
