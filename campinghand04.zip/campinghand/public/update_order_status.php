<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $order_id = $_POST['order_id'];
  $status = $_POST['status'];

  $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
  $stmt->execute([$status, $order_id]);

  header("Location: order_detail.php?id=" . $order_id);
  exit();
}
?>
