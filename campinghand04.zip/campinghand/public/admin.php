<?php
require_once '../config/db.php';
require_once '../includes/auth.php';
require_role('admin');

// ดึงจำนวนข้อมูลจากฐานข้อมูลด้วย PDO
$total_products = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_orders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>แผงควบคุมผู้ดูแลระบบ | Camping Hand</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background-color: #f7f9fc;
    }
  </style>
</head>
<body class="flex flex-col min-h-screen">

  <!-- Navbar -->
  <header class="bg-white shadow-md">
    <div class="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
      <h1 class="text-xl font-bold text-gray-800">
        Camping Hand <span class="text-red-500 text-sm bg-red-100 px-2 py-1 rounded-lg ml-2">Admin</span>
      </h1>
      <a href="logout.php" class="text-red-500 hover:text-red-700 font-medium">ออกจากระบบ</a>
    </div>
  </header>

  <!-- Main -->
  <main class="flex-grow flex flex-col justify-center items-center py-10 px-4">
    <div class="bg-white shadow-lg rounded-2xl p-10 w-full max-w-5xl text-center">
      <h2 class="text-2xl font-extrabold text-gray-900 mb-2">แผงควบคุมผู้ดูแลระบบ</h2>
      <p class="text-gray-500 mb-10">ตรวจสอบสถิติและจัดการระบบ Camping Hand ได้ที่นี่</p>

      <!-- Dashboard สรุปยอดรวม -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">

        <!-- สินค้าทั้งหมด -->
        <div class="bg-gradient-to-br from-yellow-400 to-yellow-500 text-white rounded-xl py-6 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1">
          <div class="text-3xl font-bold mb-2"><?= $total_products ?></div>
          <p class="text-lg font-medium">จำนวนสินค้า</p>
        </div>

        <!-- ผู้ใช้ทั้งหมด -->
        <div class="bg-gradient-to-br from-green-400 to-green-500 text-white rounded-xl py-6 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1">
          <div class="text-3xl font-bold mb-2"><?= $total_users ?></div>
          <p class="text-lg font-medium">จำนวนผู้ใช้</p>
        </div>

        <!-- คำสั่งซื้อทั้งหมด -->
        <div class="bg-gradient-to-br from-blue-400 to-blue-500 text-white rounded-xl py-6 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1">
          <div class="text-3xl font-bold mb-2"><?= $total_orders ?></div>
          <p class="text-lg font-medium">คำสั่งซื้อทั้งหมด</p>
        </div>

      </div>

      <!-- ปุ่มจัดการ -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">

        <!-- 🟡 จัดการสินค้า -->
        <a href="admin_products.php"
           class="bg-gradient-to-br from-yellow-400 to-yellow-500 text-white py-5 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl hover:opacity-90 transform hover:-translate-y-1 transition-all">
           🛒 จัดการสินค้า
        </a>

        <!-- 💚 จัดการผู้ใช้ -->
        <a href="admin_users.php"
           class="bg-gradient-to-br from-green-400 to-green-500 text-white py-5 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl hover:opacity-90 transform hover:-translate-y-1 transition-all">
           👥 จัดการผู้ใช้
        </a>

        <!-- 💙 จัดการคำสั่งซื้อ -->
        <a href="admin_orders.php"
           class="bg-gradient-to-br from-blue-400 to-blue-500 text-white py-5 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl hover:opacity-90 transform hover:-translate-y-1 transition-all">
           📦 จัดการคำสั่งซื้อ
        </a>

      </div>
    </div>
  </main>

  <!-- Footer -->
  <footer class="text-center text-gray-500 text-sm py-4">
    © 2025 Camping Hand — ระบบจัดการร้านค้า
  </footer>

</body>
</html>
