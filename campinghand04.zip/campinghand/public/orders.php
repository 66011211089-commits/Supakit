<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('user');

$orders = $pdo->prepare("
  SELECT id, total_amount, created_at
  FROM orders
  WHERE user_id = ?
  ORDER BY created_at DESC
");
$orders->execute([$_SESSION['user_id']]);
$list = $orders->fetchAll();
?>
<!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8">
  <title>ประวัติคำสั่งซื้อ - Camping Hand</title>
  <link rel="stylesheet" href="/assets/styles.css">
  <style>
    body { background-color: var(--bg-inner); }
    table { width: 100%; border-collapse: collapse; margin-top: 16px; }
    th, td { padding: 10px; border-bottom: 1px solid #e2e2e2; text-align: center; }
    th { background: #fafafa; }
    .container { max-width: 900px; margin: auto; background: #fff; border-radius: 12px; padding: 24px; }
    .brand { font-weight: 700; font-size: 1.3rem; color: var(--brand); }
    a { color: var(--brand-dark); text-decoration: none; }
    a:hover { text-decoration: underline; }
  </style>
</head>
<body>
  <header class="header">
    <div class="container nav">
      <div class="brand">Camping Hand <span class="badge">Orders</span></div>
      <a href="/products.php">กลับหน้าหลัก</a>
      <a href="/logout.php">ออกจากระบบ</a>
    </div>
  </header>

  <main class="container" style="margin-top:24px;">
    <h1>🧾 ประวัติคำสั่งซื้อของคุณ</h1>
    <?php if (!$list): ?>
      <div class="helper">ยังไม่มีคำสั่งซื้อ</div>
    <?php else: ?>
      <table>
        <tr><th>หมายเลขคำสั่งซื้อ</th><th>ยอดรวม</th><th>วันที่สั่งซื้อ</th><th></th></tr>
        <?php foreach ($list as $o): ?>
        <tr>
          <td>#<?= $o['id'] ?></td>
          <td><?= number_format($o['total_amount'],2) ?> ฿</td>
          <td><?= $o['created_at'] ?></td>
          <td><a href="/order_detail.php?id=<?= $o['id'] ?>">ดูรายละเอียด</a></td>
        </tr>
        <?php endforeach; ?>
      </table>
    <?php endif; ?>
  </main>
</body>
</html>