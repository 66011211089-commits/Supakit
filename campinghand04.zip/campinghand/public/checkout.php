<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('user');

// ถ้ามีการกดยืนยันสั่งซื้อ
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo->beginTransaction();

    // สร้างคำสั่งซื้อ
    $stmt = $pdo->prepare("INSERT INTO orders (user_id, total_amount) VALUES (?, ?)");
    $stmt->execute([$_SESSION['user_id'], $_POST['total']]);
    $order_id = $pdo->lastInsertId();

    // ดึงสินค้าจากตะกร้า
    $items = $pdo->prepare("SELECT * FROM cart WHERE user_id = ?");
    $items->execute([$_SESSION['user_id']]);
    $rows = $items->fetchAll();

    // เพิ่มสินค้าเข้า order_items
    foreach ($rows as $i) {
        $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)")
            ->execute([$order_id, $i['product_id'], $i['quantity']]);
    }

    // ล้างตะกร้า
    $pdo->prepare("DELETE FROM cart WHERE user_id = ?")->execute([$_SESSION['user_id']]);

    $pdo->commit();

    echo "<script>alert('สั่งซื้อสำเร็จ! หมายเลขคำสั่งซื้อ: #$order_id'); window.location='/orders.php';</script>";
    exit;
}

// ดึงข้อมูลตะกร้า
$items = $pdo->prepare("
  SELECT c.*, p.name, p.price 
  FROM cart c 
  JOIN products p ON c.product_id = p.id 
  WHERE c.user_id = ?
");
$items->execute([$_SESSION['user_id']]);
$cart = $items->fetchAll();

$total = 0;
foreach ($cart as $i) $total += $i['price'] * $i['quantity'];
?>
<!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8">
  <title>ยืนยันการสั่งซื้อ - Camping Hand</title>
  <link rel="stylesheet" href="/assets/styles.css">
</head>
<body>
<header class="header">
  <div class="container nav">
    <div class="brand">Camping Hand <span class="badge">Checkout</span></div>
    <a href="/cart.php">กลับไปตะกร้า</a>
  </div>
</header>
<main class="container" style="margin-top:24px;">
  <h1>ยืนยันคำสั่งซื้อ</h1>
  <table class="table">
    <tr><th>สินค้า</th><th>ราคา</th><th>จำนวน</th><th>รวม</th></tr>
    <?php foreach ($cart as $i): ?>
      <tr>
        <td><?= htmlspecialchars($i['name']) ?></td>
        <td><?= number_format($i['price'],2) ?> ฿</td>
        <td><?= $i['quantity'] ?></td>
        <td><?= number_format($i['price']*$i['quantity'],2) ?> ฿</td>
      </tr>
    <?php endforeach; ?>
  </table>
  <h2>รวมทั้งหมด: <?= number_format($total,2) ?> บาท</h2>
  <form method="post">
    <input type="hidden" name="total" value="<?= $total ?>">
    <button class="btn" type="submit">ยืนยันสั่งซื้อ</button>
  </form>
</main>
</body>
</html>
