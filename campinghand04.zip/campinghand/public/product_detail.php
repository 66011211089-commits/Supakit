<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

define('DB_HOST','localhost');
define('DB_NAME','campinghand');
define('DB_USER','root');
define('DB_PASS','');

try {
  $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
  ]);
} catch(PDOException $e) {
  die("DB connection failed: " . htmlspecialchars($e->getMessage()));
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if (!$product) {
  die("<p class='text-center text-red-600 mt-10'>ไม่พบสินค้านี้ในระบบ</p>");
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($product['name']) ?> | Camping Hand</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
body { font-family: 'Inter', sans-serif; background-color: #f9fafb; }
.btn { transition: all .2s; }
.btn:hover { transform: translateY(-2px); }
</style>
</head>
<body>
<header class="flex justify-between items-center p-6 bg-white shadow-sm">
  <h1 class="text-xl font-bold text-gray-800">Camping Hand <span class="text-red-500 text-sm font-medium">รายละเอียดสินค้า</span></h1>
  <a href="products.php" class="text-red-500 hover:underline text-sm">ย้อนกลับ</a>
</header>

<main class="flex justify-center p-6">
  <div class="bg-white rounded-2xl shadow-md p-8 w-full max-w-4xl flex flex-col md:flex-row items-center gap-8">
    <?php
      $imgPath = htmlspecialchars($product['image']);
      if (!file_exists(__DIR__ . '/' . $imgPath)) {
          $imgPath = 'uploads/' . basename($product['image']);
      }
    ?>
    <img src="<?= $imgPath ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-72 h-72 object-cover rounded-lg bg-gray-100 border">

    <div class="flex-1">
      <h2 class="text-2xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($product['name']) ?></h2>
      <p class="text-gray-700 mb-1">ราคา: <span class="text-red-600 font-semibold"><?= number_format($product['price'], 2) ?> บาท</span></p>
      <p class="text-gray-500 mb-1">หมวดหมู่: <?= htmlspecialchars($product['category'] ?? '-') ?></p>
      <p class="text-gray-500 mb-4">ผู้ขาย: Camping Hand</p>
      <h3 class="text-gray-800 font-semibold mb-2">รายละเอียดสินค้า:</h3>
      <p class="text-gray-600 leading-relaxed mb-6"><?= nl2br(htmlspecialchars($product['description'] ?? 'ไม่มีรายละเอียดสินค้า')) ?></p>

      <div class="flex gap-3">
        <a href="cart_add.php?id=<?= $product['id'] ?>" class="btn bg-orange-500 hover:bg-orange-600 text-white px-5 py-2 rounded-lg shadow">เพิ่มลงตะกร้า</a>
        <a href="cart.php" class="btn bg-red-500 hover:bg-red-600 text-white px-5 py-2 rounded-lg shadow">ไปหน้าตะกร้า</a>
      </div>
    </div>
  </div>
</main>
</body>
</html>
