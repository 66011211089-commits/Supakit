CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','user') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO users (name,email,password_hash,role)
VALUES ('Super Admin','admin@campinghand.local','$2y$10$gH8oC7bFmr8gT9n6p2d6wO2yJfM6yH4edY9zJ6euO7B0qfP1p5KpK','admin')
ON DUPLICATE KEY UPDATE email=email;
