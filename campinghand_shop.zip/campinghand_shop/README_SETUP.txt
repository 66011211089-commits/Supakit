SETUP

1. Import database
   - เปิด phpMyAdmin
   - Import ไฟล์ campinghand_shop.sql
   - จะได้ DB: campinghand_shop และตาราง users

2. รันเว็บ
   เปิด Terminal / PowerShell ตำแหน่งโฟลเดอร์นี้ แล้วรัน:
   php -S localhost:8000 -t public

3. เปิดเว็บ
   http://localhost:8000/login.php
   http://localhost:8000/register.php

4. config DB edit ได้ที่ config/db.php
