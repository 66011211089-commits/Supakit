<?php
session_start();

// ดึง DB (ใช้ mysqli เดิมของโปรเจกต์)
require_once __DIR__ . '/../config/db.php';

// ดึงฟังก์ชันตรวจสิทธิ์
require_once __DIR__ . '/includes/auth.php';

// บังคับว่าต้องเป็น admin เท่านั้น
require_role('admin');

// ------------------------------------------------------------------
// ดึงจำนวนสถิติด้วย mysqli ($conn)
// ------------------------------------------------------------------

$total_products = 0;
$total_users = 0;
$total_orders = 0;

// ถ้า table พวกนี้ยังไม่ได้สร้างใน DB จริงของมึง
// มันจะ error ตอน query ได้ เราเลยเช็คทีละอันแบบ safe

// products
if ($result = $conn->query("SHOW TABLES LIKE 'products'")) {
    if ($result->num_rows > 0) {
        $res2 = $conn->query("SELECT COUNT(*) AS c FROM products");
        if ($row2 = $res2->fetch_assoc()) {
            $total_products = (int)$row2['c'];
        }
        $res2->free();
    }
    $result->free();
}

// users (ตารางนี้เรามีอยู่แล้ว)
$res3 = $conn->query("SELECT COUNT(*) AS c FROM users");
if ($row3 = $res3->fetch_assoc()) {
    $total_users = (int)$row3['c'];
}
$res3->free();

// orders (อาจยังไม่มี เราเช็คก่อน)
if ($result4 = $conn->query("SHOW TABLES LIKE 'orders'")) {
    if ($result4->num_rows > 0) {
        $res4 = $conn->query("SELECT COUNT(*) AS c FROM orders");
        if ($row4 = $res4->fetch_assoc()) {
            $total_orders = (int)$row4['c'];
        }
        $res4->free();
    }
    $result4->free();
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>แผงควบคุมผู้ดูแลระบบ | Camping Hand</title>
  <link rel="preconnect" href="https://fonts.gstatic.com"/>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>

  <style>
    :root {
      --bg-page:#f7f9fc;
      --card-bg:#fff;
      --text-main:#1a1a1a;
      --text-dim:#6b6b6b;
      --radius-lg:16px;
      --shadow-card:0 24px 40px rgba(0,0,0,.08);
      --shadow-header:0 8px 24px rgba(0,0,0,.03);
    }
    *{
      box-sizing:border-box;
      font-family:'Inter',system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;
      -webkit-font-smoothing:antialiased;
      margin:0;
      padding:0;
    }
    body{
      background:var(--bg-page);
      color:var(--text-main);
      min-height:100vh;
      display:flex;
      flex-direction:column;
    }

    /* header */
    .admin-header{
      width:100%;
      background:#fff;
      border-bottom:1px solid #e4e4e4;
      box-shadow:var(--shadow-header);
      padding:12px 20px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      position:sticky;
      top:0;
      z-index:1000;
      font-size:.9rem;
    }
    .brandline{
      display:flex;
      align-items:center;
      gap:8px;
      font-weight:600;
      color:#1a1a1a;
      font-size:1rem;
    }
    .pill-admin{
      font-size:.7rem;
      font-weight:600;
      color:#ff4d30;
      background:#ffe4de;
      border-radius:999px;
      padding:2px 8px;
      line-height:1.2;
    }
    .logout-link{
      text-decoration:none;
      font-weight:600;
      color:#ff4d30;
      font-size:.8rem;
    }

    main{
      flex:1;
      width:100%;
      max-width:1280px;
      margin:32px auto 24px;
      padding:0 16px;
      display:flex;
      justify-content:center;
      align-items:flex-start;
    }

    .admin-card{
      background:var(--card-bg);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-card);
      border:1px solid #e4e4e4;
      padding:32px 24px;
      width:100%;
      max-width:820px;
      text-align:center;
    }
    .title-head{
      font-size:1.25rem;
      font-weight:700;
      color:#1a1a1a;
      line-height:1.3;
      margin-bottom:4px;
    }
    .desc-head{
      font-size:.85rem;
      color:#6b6b6b;
      line-height:1.4;
      margin-bottom:28px;
    }

    .stats-grid{
      width:100%;
      display:grid;
      grid-template-columns:repeat(auto-fit,minmax(min(220px,100%),1fr));
      gap:16px;
      margin-bottom:28px;
    }

    .stat-box{
      border-radius:12px;
      color:#fff;
      padding:24px 16px;
      font-weight:600;
      box-shadow:0 16px 32px rgba(0,0,0,.15);
      transition:.15s;
    }
    .stat-box:hover{
      transform:translateY(-2px);
      box-shadow:0 24px 40px rgba(0,0,0,.18);
    }
    .stat-number{
      font-size:1.8rem;
      font-weight:700;
      margin-bottom:6px;
    }
    .stat-label{
      font-size:1rem;
    }

    .yell-bg{
      background:linear-gradient(to bottom right,#facc15,#eab308);
    }
    .green-bg{
      background:linear-gradient(to bottom right,#4ade80,#22c55e);
    }
    .blue-bg{
      background:linear-gradient(to bottom right,#60a5fa,#3b82f6);
    }

    .actions-grid{
      display:grid;
      grid-template-columns:repeat(auto-fit,minmax(min(220px,100%),1fr));
      gap:16px;
    }
    .action-btn{
      display:block;
      text-decoration:none;
      border-radius:12px;
      color:#fff;
      font-weight:600;
      font-size:1rem;
      text-align:center;
      padding:20px 16px;
      box-shadow:0 16px 32px rgba(0,0,0,.15);
      transition:.15s;
    }
    .action-btn:hover{
      transform:translateY(-2px);
      box-shadow:0 24px 40px rgba(0,0,0,.18);
      opacity:.95;
    }

    footer{
      font-size:.7rem;
      color:#6b6b6b;
      text-align:center;
      padding:24px 16px 32px;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <header class="admin-header">
    <div class="brandline">
      <div>Camping Hand</div>
      <div class="pill-admin">Admin</div>
    </div>

    <a href="logout.php" class="logout-link">ออกจากระบบ</a>
  </header>

  <!-- Main -->
  <main>
    <div class="admin-card">
      <div class="title-head">แผงควบคุมผู้ดูแลระบบ</div>
      <div class="desc-head">ตรวจสอบสถิติและจัดการระบบ Camping Hand ได้ที่นี่</div>

      <!-- Dashboard summary -->
      <div class="stats-grid">
        <div class="stat-box yell-bg">
          <div class="stat-number"><?php echo $total_products; ?></div>
          <div class="stat-label">จำนวนสินค้า</div>
        </div>

        <div class="stat-box green-bg">
          <div class="stat-number"><?php echo $total_users; ?></div>
          <div class="stat-label">จำนวนผู้ใช้</div>
        </div>

        <div class="stat-box blue-bg">
          <div class="stat-number"><?php echo $total_orders; ?></div>
          <div class="stat-label">คำสั่งซื้อทั้งหมด</div>
        </div>
      </div>

      <!-- Action buttons -->
      <div class="actions-grid">
        <a class="action-btn yell-bg" href="admin_products.php">🛒 จัดการสินค้า</a>
        <a class="action-btn green-bg" href="admin_users.php">👥 จัดการผู้ใช้</a>
        <a class="action-btn blue-bg" href="admin_orders.php">📦 จัดการคำสั่งซื้อ</a>
      </div>
    </div>
  </main>

  <!-- Footer -->
  <footer>
    © 2025 Camping Hand — ระบบจัดการร้านค้า
  </footer>

</body>
</html>
