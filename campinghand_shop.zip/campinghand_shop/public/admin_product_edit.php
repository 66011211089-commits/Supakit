<?php
require_once '../config/db.php';
require_once './includes/auth.php';
require_role('admin');

// ---------------------- GET PRODUCT ----------------------
if (!isset($_GET['id'])) {
    die('ไม่พบรหัสสินค้า');
}
$product_id = intval($_GET['id']);

$stmt = $conn->prepare("SELECT * FROM products WHERE product_id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product_res = $stmt->get_result();
if ($product_res->num_rows === 0) {
    die('ไม่พบข้อมูลสินค้า');
}
$product = $product_res->fetch_assoc();
$stmt->close();

// ---------------------- UPDATE (POST) ----------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name             = $_POST['product_name'] ?? '';
    $detail           = $_POST['product_detail'] ?? '';
    $price            = $_POST['price'] ?? 0;
    $category_id      = $_POST['category_id'] ?? 0;
    $condition_status = $_POST['condition_status'] ?? '';

    // รูปเดิมใน DB (เช่น "uploads/prod_123.jpg")
    $current_image_path = $product['image_path'];
    
    // ค่าที่จะบันทึกลง DB, เริ่มต้นให้เป็นค่าเดิม
    $new_image_path_for_db = $current_image_path;

    // ถ้ามีการอัปโหลดรูปใหม่
    if (!empty($_FILES['image']['name']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        
        $upload_dir = "uploads/"; // โฟลเดอร์ที่เก็บ
        if (!is_dir($upload_dir)) {
            @mkdir($upload_dir, 0755, true);
        }

        // สร้างชื่อไฟล์ใหม่ (เฉพาะชื่อไฟล์)
        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $new_filename_only = "prod_" . time() . "_" . bin2hex(random_bytes(2)) . "." . $ext;
        
        // path แบบ relative ที่จะใช้ย้ายไฟล์ และเก็บลง DB (เช่น "uploads/new_prod.jpg")
        $new_relative_path = $upload_dir . $new_filename_only; 

        if (move_uploaded_file($_FILES['image']['tmp_name'], $new_relative_path)) {
            // ย้ายไฟล์ใหม่สำเร็จ
            
            // 1. ลบไฟล์เก่าออกถ้ามี (ตัวแปร $current_image_path มี "uploads/" อยู่แล้ว)
            if (!empty($current_image_path) && file_exists($current_image_path)) {
                @unlink($current_image_path);
            }
            
            // 2. ตั้งค่า path ใหม่ที่จะบันทึกลง DB
            $new_image_path_for_db = $new_relative_path;

        } else {
            // ถ้าอัปโหลดไม่สำเร็จ ให้คงค่าเดิมไว้ (ไม่ต้องทำอะไร $new_image_path_for_db ยังเป็นค่าเดิม)
        }
    }

    $upd = $conn->prepare("
        UPDATE products
        SET product_name = ?,
            product_detail = ?,
            price = ?,
            category_id = ?,
            condition_status = ?,
            image_path = ?
        WHERE product_id = ?
    ");
    $upd->bind_param(
        "ssdissi",
        $name,
        $detail,
        $price,
        $category_id,
        $condition_status,
        $new_image_path_for_db, // *** ใช้ตัวแปรที่แก้แล้ว ***
        $product_id
    );
    $upd->execute();
    $upd->close();

    header("Location: admin_products.php");
    exit;
}

// ---------------------- GET CATEGORIES ----------------------
$cats_res = $conn->query("SELECT category_id, category_name, category_code FROM categories ORDER BY category_id ASC");
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>แก้ไขสินค้า | Camping Hand</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans">

    <header class="bg-white shadow-md">
        <div class="max-w-5xl mx-auto px-6 py-4 flex justify-between items-center">
            <h1 class="text-xl font-bold text-gray-800">
                Camping Hand <span class="text-red-500 text-xs bg-red-100 px-2 py-1 rounded ml-2">Admin</span>
            </h1>
            <div class="space-x-4 text-sm">
                <a href="admin_products.php" class="text-gray-600 hover:text-black">กลับหน้าสินค้า</a>
                <a href="logout.php" class="text-red-500 hover:text-red-700 font-medium">ออกจากระบบ</a>
            </div>
        </div>
    </header>

    <main class="max-w-5xl mx-auto mt-8 mb-16 bg-white rounded-xl shadow p-6">
        <h2 class="text-2xl font-bold text-center mb-6">✏️ แก้ไขสินค้า</h2>

        <form method="POST" enctype="multipart/form-data" class="space-y-6">

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">ชื่อสินค้า *</label>
                    <input type="text" name="product_name" required
                           class="w-full border rounded-lg px-3 py-2"
                           value="<?= htmlspecialchars($product['product_name']) ?>">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">ราคา (฿) *</label>
                    <input type="number" step="0.01" name="price" required
                           class="w-full border rounded-lg px-3 py-2"
                           value="<?= htmlspecialchars($product['price']) ?>">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">หมวดหมู่ *</label>
                    <select name="category_id" required
                            class="w-full border rounded-lg px-3 py-2">
                        <?php while ($cat = $cats_res->fetch_assoc()): ?>
                            <option value="<?= $cat['category_id']; ?>"
                                <?= $cat['category_id'] == $product['category_id'] ? 'selected' : ''; ?>>
                                <?= htmlspecialchars($cat['category_name']); ?>
                                (<?= htmlspecialchars($cat['category_code']); ?>)
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">สภาพสินค้า</label>
                    <input type="text" name="condition_status"
                           class="w-full border rounded-lg px-3 py-2"
                           value="<?= htmlspecialchars($product['condition_status']) ?>">
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">รายละเอียดสินค้า</label>
                <textarea name="product_detail" rows="3"
                          class="w-full border rounded-lg px-3 py-2"
                          placeholder="รายละเอียด เช่น วัสดุ ขนาด น้ำหนัก จุดเด่น"><?= htmlspecialchars($product['product_detail']) ?></textarea>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">รูปภาพปัจจุบัน</label>
                    <?php if (!empty($product['image_path'])): ?>
                        <!-- *** แก้ไข: ลบ class ที่ซ้ำกันออก *** -->
                        <img src="<?= htmlspecialchars($product['image_path']) ?>"
                             class="w-28 h-28 object-cover rounded border">
                    <?php else: ?>
                        <div class="text-gray-400 text-sm italic">ไม่มีรูปเดิม</div>
                    <?php endif; ?>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">อัปโหลดรูปใหม่ (ถ้ามี)</label>
                    <input type="file" name="image" class="block w-full text-sm text-gray-700 border rounded-lg px-3 py-2 bg-gray-50">
                    <p class="text-xs text-gray-500 mt-1">รองรับ .jpg .jpeg .png .webp</p>
                </div>
            </div>

            <div class="flex flex-col md:flex-row justify-between gap-4 pt-6">
                <a href="admin_products.php"
                   class="text-center bg-gray-400 hover:bg-gray-500 text-white font-medium px-5 py-2 rounded-lg">
                    ยกเลิก / กลับ
                </a>

                <button type="submit"
                        class="bg-green-500 hover:bg-green-600 text-white font-semibold px-5 py-2 rounded-lg shadow">
                    💾 บันทึกการแก้ไข
                </button>
            </div>
        </form>
    </main>

    <footer class="text-center text-gray-500 text-xs pb-10">
        © 2025 Camping Hand — ระบบจัดการร้านค้า
    </footer>

</body>
</html>
