<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/includes/auth.php';

// ต้องเป็น admin เท่านั้น
require_role('admin');

$message = "";
$user = null;
$user_id = 0;
$current_admin_id = $_SESSION['user_id'] ?? 0;

// 1. ตรวจสอบว่ามี ID ส่งมาหรือไม่
if (!isset($_GET['id'])) {
    header("Location: admin_users.php");
    exit;
}
$user_id = intval($_GET['id']);

// 2. ป้องกันแอดมินลบตัวเอง
if ($user_id === $current_admin_id) {
    // ใช้ session flash message (ถ้ามีระบบ) หรือส่ง query param กลับไป
    $_SESSION['error_message'] = "คุณไม่สามารถลบบัญชีของตัวเองได้";
    header("Location: admin_users.php");
    exit;
}

// 3. ดึงข้อมูลผู้ใช้ที่จะลบ
$stmt = $conn->prepare("SELECT user_id, username, email, role FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
} else {
    // ไม่พบผู้ใช้
    header("Location: admin_users.php");
    exit;
}
$stmt->close();

// 4. ถ้ามีการ POST (กดยืนยันลบ)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    
    // *** สำคัญ: ในอนาคต ต้องเช็คก่อนว่า user นี้มี orders ค้างอยู่หรือไม่
    // (ตอนนี้จะลบเลย)
    
    $delete_stmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
    $delete_stmt->bind_param("i", $user_id);
    
    if ($delete_stmt->execute()) {
        // ลบสำเร็จ กลับไปหน้า list
        header("Location: admin_users.php");
        exit;
    } else {
         $message = '<div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
            <strong class="font-bold">ผิดพลาด!</strong>
            <span class="block sm:inline">ไม่สามารถลบผู้ใช้นี้ได้ (อาจมีข้อมูลคำสั่งซื้อผูกอยู่)</span>
          </div>';
    }
    $delete_stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ลบผู้ใช้ #<?= $user['user_id'] ?> | Camping Hand Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body class="bg-gray-100 font-sans">

    <!-- Header -->
    <header class="bg-white shadow-md">
         <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                 <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">
                        Camping Hand <span class="text-red-500 text-xs bg-red-100 px-2 py-1 rounded-md ml-2">Admin</span>
                    </h1>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-md mx-auto py-8 px-4 sm:px-6 lg:px-8">
        
        <div class="bg-white shadow-lg rounded-xl p-6 sm:p-8 text-center">
            
            <i class="fa-solid fa-triangle-exclamation text-6xl text-red-500 mb-4"></i>
            
            <h2 class="text-2xl font-bold text-gray-900 mb-2">
                ยืนยันการลบผู้ใช้งาน
            </h2>
            <p class="text-gray-600 mb-6">
                คุณแน่ใจหรือไม่ว่าต้องการลบผู้ใช้งานคนนี้ออกจากระบบ?
                การกระทำนี้ <strong class="text-red-600">ไม่สามารถย้อนกลับได้</strong>
            </p>

            <?= $message ?> <!-- แสดงข้อความ (ถ้าลบไม่สำเร็จ) -->

            <!-- User Info Card -->
            <div class="bg-gray-50 border border-gray-200 rounded-lg p-4 text-left mb-6">
                <div class="flex items-center">
                    <div class="mr-3">
                        <?php if ($user['role'] === 'admin'): ?>
                             <i class="fa-solid fa-user-shield text-2xl text-red-500"></i>
                        <?php else: ?>
                             <i class="fa-solid fa-user text-2xl text-gray-500"></i>
                        <?php endif; ?>
                    </div>
                    <div>
                        <div class="font-bold text-gray-800"><?= htmlspecialchars($user['username']) ?></div>
                        <div class="text-sm text-gray-600"><?= htmlspecialchars($user['email']) ?></div>
                        <div class="text-xs text-gray-500 mt-1">ID: <?= $user['user_id'] ?></div>
                    </div>
                </div>
            </div>
            
            <!-- Buttons -->
            <form method="POST" action="admin_user_delete.php?id=<?= $user['user_id'] ?>">
                <div class="flex flex-col sm:flex-row-reverse gap-3">
                    <button type="submit" name="confirm_delete"
                            class="w-full bg-red-600 hover:bg-red-700 text-white font-medium px-6 py-2 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">
                        <i class="fa-solid fa-trash-can mr-2"></i>
                        ใช่, ฉันต้องการลบ
                    </button>
                    <a href="admin_users.php"
                       class="w-full text-center bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium px-6 py-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400">
                        ยกเลิก
                    </a>
                </div>
            </form>

        </div>

    </main>

    <footer class="text-center text-gray-500 text-xs py-10">
        © <?= date('Y') ?> Camping Hand — ระบบจัดการร้านค้า
    </footer>

</body>
</html>
