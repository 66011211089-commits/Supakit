<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/includes/auth.php';

// ต้องเป็น admin เท่านั้น
require_role('admin');

// ดึงข้อมูลผู้ใช้ทั้งหมดจากตาราง users
// เรียงจาก user_id น้อยไปมาก
$result = $conn->query("SELECT * FROM users ORDER BY user_id ASC");
$users = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    $result->free();
}

// (เพิ่ม) เช็คว่ามี error message จากหน้า delete (กรณีลบตัวเอง) หรือไม่
$error_message = "";
if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']); // เคลียร์ message หลังแสดงผล
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>จัดการผู้ใช้ | Camping Hand Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body class="bg-gray-100 font-sans">

    <!-- Header -->
    <header class="bg-white shadow-md">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">
                        Camping Hand <span class="text-red-500 text-xs bg-red-100 px-2 py-1 rounded-md ml-2">Admin</span>
                    </h1>
                </div>
                <div class="flex items-center space-x-4 text-sm">
                    <a href="admin.php" class="text-gray-600 hover:text-black">
                        <i class="fa-solid fa-tachometer-alt mr-1"></i>
                        แผงควบคุม
                    </a>
                    <a href="logout.php" class="text-red-500 hover:text-red-700 font-medium">
                        <i class="fa-solid fa-right-from-bracket mr-1"></i>
                        ออกจากระบบ
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold text-gray-900">
                <i class="fa-solid fa-users mr-2"></i>
                จัดการผู้ใช้งาน (Users)
            </h2>
            <!-- <a href="admin_user_add.php" class="bg-green-500 hover:bg-green-600 text-white font-medium px-4 py-2 rounded-lg shadow-sm">
                <i class="fa-solid fa-plus mr-1"></i>
                เพิ่มผู้ใช้ใหม่
            </a> -->
        </div>

        <!-- (เพิ่ม) แสดง Error Message (เช่น ลบตัวเอง) -->
        <?php if (!empty($error_message)): ?>
             <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong class="font-bold">ผิดพลาด!</strong>
                <span class="block sm:inline"><?= htmlspecialchars($error_message) ?></span>
              </div>
        <?php endif; ?>

        <!-- Users Table -->
        <div class="bg-white shadow-lg rounded-xl overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full min-w-max text-sm text-left text-gray-700">
                    <thead class="text-xs text-gray-800 uppercase bg-gray-100 border-b">
                        <tr>
                            <th scope="col" class="px-6 py-3">ID</th>
                            <th scope="col" class="px-6 py-3">ชื่อผู้ใช้</th>
                            <th scope="col" class="px-6 py-3">Email</th>
                            <!-- <th scope="col" class="px-6 py-3">ชื่อ-สกุล</th> (ลบออก) -->
                            <th scope="col" class="px-6 py-3">เบอร์โทร</th>
                            <th scope="col" class="px-6 py-3">สิทธิ์ (Role)</th>
                            <th scope="col" class="px-6 py-3">วันที่สมัคร</th>
                            <th scope="col" class="px-6 py-3 text-center">จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($users)): ?>
                            <tr class="bg-white border-b">
                                <td colspan="7" class="px-6 py-4 text-center text-gray-500">
                                    <i class="fa-solid fa-ghost mr-2"></i>
                                    ไม่พบข้อมูลผู้ใช้งาน
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($users as $user): ?>
                                <tr class="bg-white border-b hover:bg-gray-50 align-top">
                                    <td class="px-6 py-4 font-medium text-gray-900">
                                        <?= $user['user_id'] ?>
                                    </td>
                                    <td class="px-6 py-4 font-medium text-blue-600">
                                        <?= htmlspecialchars($user['username']) ?>
                                    </td>
                                    <td class="px-6 py-4">
                                        <?= htmlspecialchars($user['email']) ?>
                                    </td>
                                    <!-- 
                                        (ลบ <td> ของ first_name/last_name ออก)
                                    -->
                                    <td class="px-6 py-4">
                                        <!-- แก้ไขส่วนเบอร์โทรด้วยตรรกะเดียวกัน -->
                                        <?php
                                            if (empty($user['phone'])) {
                                                echo '<span class="text-gray-400">—</span>';
                                            } else {
                                                echo htmlspecialchars($user['phone']);
                                            }
                                        ?>
                                    </td>
                                    <td class="px-6 py-4">
                                        <?php if ($user['role'] === 'admin'): ?>
                                            <span class="px-2 py-1 text-xs font-semibold text-red-800 bg-red-100 rounded-full">
                                                Admin
                                            </span>
                                        <?php else: ?>
                                            <span class="px-2 py-1 text-xs font-semibold text-gray-800 bg-gray-100 rounded-full">
                                                Customer
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-gray-500 text-xs">
                                        <?= date('d M Y, H:i', strtotime($user['created_at'])) ?>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <!-- *** START: แก้ไขตรงนี้ *** -->
                                        <div class="flex justify-center space-x-2">
                                            
                                            <a href="admin_user_edit.php?id=<?= $user['user_id'] ?>"
                                               class="text-blue-600 hover:text-blue-800" title="แก้ไข">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </a>

                                            <?php
                                            // ตรวจสอบว่า user นี้คือ admin ที่ login อยู่หรือไม่
                                            $current_admin_id = $_SESSION['user_id'] ?? 0;
                                            if ($user['user_id'] == $current_admin_id):
                                            ?>
                                                <!-- ถ้าใช่ ให้ปิดปุ่มลบ (ลบตัวเองไม่ได้) -->
                                                <button disabled class="text-red-300 cursor-not-allowed" title="คุณไม่สามารถลบตัวเองได้">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </button>
                                            <?php else: ?>
                                                <!-- ถ้าไม่ใช่ user อื่น ให้เปิดปุ่มลบ -->
                                                <a href="admin_user_delete.php?id=<?= $user['user_id'] ?>"
                                                   class="text-red-500 hover:text-red-700" title="ลบ"
                                                   onclick="return confirm('คุณแน่ใจหรือไม่ว่าต้องการลบผู้ใช้ \'<?= htmlspecialchars($user['username']) ?>\'?');">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </a>
                                            <?php endif; ?>

                                        </div>
                                        <!-- *** END: แก้ไขตรงนี้ *** -->
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>

    <footer class="text-center text-gray-500 text-xs py-10">
        © <?= date('Y') ?> Camping Hand — ระบบจัดการร้านค้า
    </footer>

</body>
</html>

