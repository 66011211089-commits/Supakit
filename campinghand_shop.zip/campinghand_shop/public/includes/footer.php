</div><!-- /page-shell -->

<footer class="footer-copy">
    © Camping Hand
</footer>

</body>
</html>
