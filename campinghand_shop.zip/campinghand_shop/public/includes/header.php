<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Camping Hand — Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header class="header-bar">
    <div class="brand-area">
        <div class="brand-name">Camping Hand</div>
        <div class="beta-pill">Beta</div>
    </div>

    <nav class="header-links">
        <?php if(isset($_SESSION['user_id'])): ?>
            <?php if (isset($_SESSION['username'])): ?>
                <span style="color:#555;font-size:.8rem;font-weight:500;">สวัสดี, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            <?php endif; ?>
            <a href="logout.php">ออกจากระบบ</a>
        <?php else: ?>
            <a href="register.php">สมัครสมาชิก</a>
        <?php endif; ?>
    </nav>
</header>

<div class="page-shell">
