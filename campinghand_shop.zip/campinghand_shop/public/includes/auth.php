<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ถ้ายังไม่ได้ล็อกอิน จะเด้งกลับหน้า login
function require_login() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit;
    }
}

// ถ้า role ไม่ตรง (เช่นไม่ใช่ admin) จะเด้งกลับ login
function require_role($role_needed) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit;
    }
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== $role_needed) {
        header("Location: login.php");
        exit;
    }
}
