<?php
session_start();
require_once __DIR__ . '/../config/db.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'user'; // รับค่าจากปุ่มเลือก role

    if ($email === '' || $password === '') {
        $message = '<div class="alert error">กรุณากรอกอีเมลและรหัสผ่านให้ครบ</div>';
    } else {
        $stmt = $conn->prepare("SELECT user_id, username, password_hash, role FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 1) {
            $stmt->bind_result($uid, $uname, $passhash, $user_role);
            $stmt->fetch();

            if (password_verify($password, $passhash)) {
                $_SESSION['user_id'] = $uid;
                $_SESSION['username'] = $uname;
                $_SESSION['role'] = $user_role;

                // ✅ แอดมินเด้งเข้า admin.php
                if ($user_role === 'admin') {
                    header("Location: admin.php");
                } else {
                    header("Location: protected.php");
                }
                exit;
            } else {
                $message = '<div class="alert error">รหัสผ่านไม่ถูกต้อง</div>';
            }
        } else {
            $message = '<div class="alert error">ไม่พบบัญชีนี้ในระบบ</div>';
        }
        $stmt->close();
    }
}

include __DIR__ . "/includes/header.php";
?>

<div class="auth-card">
    <div class="auth-head">
        <div class="auth-title">เข้าสู่ระบบ</div>
        <div class="auth-desc">เลือกเข้าสู่ระบบในโหมด <b>Admin</b> หรือ <b>User</b> ได้เลย</div>
    </div>

    <?php if ($message !== ""): ?>
        <div class="form-group" style="font-size:.85rem;line-height:1.4;">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="login.php" class="form-stack">
        <!-- ปุ่มเลือก role -->
        <div class="flex justify-center gap-2 mb-4">
            <button type="button" class="role-tab active" data-role="user">User</button>
            <button type="button" class="role-tab" data-role="admin">Admin</button>
        </div>
        <input type="hidden" name="role" id="role" value="user">

        <div class="form-group">
            <label>อีเมล</label>
            <input type="email" name="email" placeholder="you@example.com" required />
        </div>

        <div class="form-group">
            <label>รหัสผ่าน</label>
            <input type="password" name="password" placeholder="••••••••" required />
        </div>

        <button class="btn-submit" type="submit">เข้าสู่ระบบ</button>
    </form>

    <div class="bottom-row">
        ยังไม่มีบัญชี? <a href="register.php">สมัครสมาชิก</a>
    </div>
</div>

<?php include __DIR__ . "/includes/footer.php"; ?>

<script>
const tabs = document.querySelectorAll('.role-tab');
const roleInput = document.getElementById('role');

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    roleInput.value = tab.dataset.role;
  });
});
</script>

<style>
body {
  background-color: #f7f9fc;
  font-family: 'Inter', sans-serif;
}
.auth-card {
  background: #fff;
  width: 100%;
  max-width: 420px;
  margin: 80px auto;
  border-radius: 1rem;
  padding: 2.5rem;
  box-shadow: 0 4px 20px rgba(0,0,0,0.05);
  text-align: center;
}
.auth-title {
  font-size: 1.6rem;
  font-weight: 800;
  margin-bottom: .25rem;
  color: #222;
}
.auth-desc {
  color: #555;
  font-size: .9rem;
  margin-bottom: 1.2rem;
}
.form-group {
  text-align: left;
  margin-bottom: 1rem;
}
.form-group label {
  display: block;
  font-size: .9rem;
  margin-bottom: .25rem;
  font-weight: 600;
  color: #444;
}
input, textarea {
  width: 100%;
  border: 1px solid #ddd;
  border-radius: .5rem;
  padding: .65rem .8rem;
  font-size: .9rem;
  transition: all .2s;
}
input:focus {
  border-color: #ff5b2e;
  outline: none;
  box-shadow: 0 0 0 3px rgba(255,91,46,0.15);
}
.btn-submit {
  background: linear-gradient(to right, #ff7b00, #ff3b2e);
  color: white;
  font-weight: 600;
  width: 100%;
  padding: .7rem;
  border: none;
  border-radius: .6rem;
  margin-top: .5rem;
  transition: all .2s;
}
.btn-submit:hover {
  opacity: 0.9;
  transform: translateY(-1px);
}
.bottom-row {
  margin-top: 1.2rem;
  font-size: .9rem;
}
.bottom-row a {
  color: #ff3b2e;
  font-weight: 600;
}
.alert {
  padding: .5rem .75rem;
  border-radius: .4rem;
  margin-bottom: .5rem;
}
.alert.error {
  background: #ffe5e0;
  color: #d20000;
}
.alert.success {
  background: #e0ffe5;
  color: #007a1a;
}
.role-tab {
  border: 1px solid #ddd;
  border-radius: .6rem;
  padding: .4rem 1.4rem;
  font-size: .9rem;
  font-weight: 600;
  cursor: pointer;
  background: white;
  transition: all .2s;
}
.role-tab.active {
  background: #ff5b2e;
  color: white;
  border-color: #ff5b2e;
}
</style>
