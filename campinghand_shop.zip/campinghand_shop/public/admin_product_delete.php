<?php
require_once '../config/db.php';
require_once './includes/auth.php';
require_role('admin');

if (!isset($_GET['id'])) {
    die('ไม่พบรหัสสินค้า');
}
$product_id = intval($_GET['id']);

// ดึงข้อมูลสินค้าเพื่อนำมาแสดงก่อนลบ
$stmt = $conn->prepare("SELECT * FROM products WHERE product_id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows === 0) {
    die('ไม่พบข้อมูลสินค้า');
}
$product = $res->fetch_assoc();
$stmt->close();

// ถ้ากดยืนยันลบ (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {

    // 1. *** แก้ไข Path ที่ลบ ***
    // (image_path มี "uploads/" อยู่แล้ว)
    if (!empty($product['image_path'])) {
        // $file_path = "uploads/" . $product['image_path']; // <- บรรทัดเดิมที่ผิด
        $file_path = $product['image_path']; // <- บรรทัดที่ถูกต้อง
        
        if (file_exists($file_path)) {
            @unlink($file_path);
        }
    }

    // ลบแถวใน DB
    $del = $conn->prepare("DELETE FROM products WHERE product_id = ?");
    $del->bind_param("i", $product_id);
    $del->execute();
    $del->close();

    header("Location: admin_products.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ยืนยันลบสินค้า | Camping Hand</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans flex items-center justify-center min-h-screen">

    <main class="max-w-md w-full bg-white rounded-xl shadow-lg p-6 m-4">
        <h2 class="text-2xl font-bold text-center mb-4 text-red-600">🗑️ ยืนยันการลบสินค้า</h2>
        <p class="text-center text-gray-600 mb-6">
            คุณแน่ใจหรือไม่ว่าต้องการลบสินค้านี้? <br>
            <span class="font-medium">การกระทำนี้ไม่สามารถย้อนกลับได้</span>
        </p>

        <!-- 2. *** แก้ไข Path รูป และรวม Class *** -->
        <?php if (!empty($product['image_path'])): ?>
            <img src="<?= htmlspecialchars($product['image_path']) ?>"
                 alt="<?= htmlspecialchars($product['product_name']) ?>"
                 class="w-32 h-32 object-cover rounded border mx-auto mb-4">
            <!-- ลบบรรทัด class ที่ซ้ำกันออกไปแล้ว -->
        <?php else: ?>
            <div class="text-gray-400 text-sm italic mb-4 text-center">ไม่มีรูป</div>
        <?php endif; ?>

        <div class="mb-4 border-t pt-4">
            <div class="text-lg font-semibold text-gray-800 text-center"><?= htmlspecialchars($product['product_name']) ?></div>
            
            <?php if(!empty($product['product_detail'])): ?>
            <div class="text-sm text-gray-500 leading-snug whitespace-pre-line text-center mt-2">
                <?= htmlspecialchars($product['product_detail']) ?>
            </div>
            <?php endif; ?>

            <div class="text-sm text-gray-600 mt-2 text-center">
                ราคา: <span class="font-medium"><?= number_format($product['price'],2) ?> ฿</span>
            </div>
            <div class="text-xs text-gray-400 mt-1 text-center">
                สภาพ: <?= htmlspecialchars($product['condition_status']) ?>
            </div>
        </div>

        <form method="POST" class="flex flex-col gap-3 mt-6">
            <button type="submit" name="confirm_delete"
                    class="bg-red-500 hover:bg-red-600 text-white font-semibold px-4 py-2 rounded-lg shadow w-full">
                ยืนยันการลบ
            </button>
            <a href="admin_products.php"
               class="bg-gray-400 hover:bg-gray-500 text-white font-medium px-4 py-2 rounded-lg text-center w-full">
                ยกเลิก / กลับ
            </a>
        </form>
    </main>

</body>
</html>
