<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/includes/auth.php';

// ต้องเป็น admin เท่านั้น
require_role('admin');

// ---------------------------
// helper: gen รหัสสินค้าใหม่ (P001, P002, ...)
// ---------------------------
function generateProductCode($conn) {
    $res = $conn->query("SELECT product_code FROM products ORDER BY product_id DESC LIMIT 1");
    if ($res && $row = $res->fetch_assoc()) {
        // ตัดตัว P ออก เอาเลขมาบวก
        $last = $row['product_code']; // เช่น "P007"
        $num = intval(substr($last, 1)); // 7
        $num++;
        return "P" . str_pad((string)$num, 3, "0", STR_PAD_LEFT);
    } else {
        // ถ้ายังไม่มีสินค้าเลย
        return "P001";
    }
}

// ---------------------------
// handle insert product (POST)
// ---------------------------
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action']==='add_product') {

    $product_name     = trim($_POST['product_name'] ?? '');
    $price            = trim($_POST['price'] ?? '');
    $category_id      = trim($_POST['category_id'] ?? '');
    $condition_status = trim($_POST['condition_status'] ?? '');
    $product_detail   = trim($_POST['product_detail'] ?? '');

    // อัปโหลดรูป
    $image_path = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {

        $tmp_name = $_FILES['image']['tmp_name'];
        $orig_name = basename($_FILES['image']['name']);

        // โฟลเดอร์เก็บรูป เช่น public/uploads/
        $uploadDir = __DIR__ . '/uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        // ตั้งชื่อไฟล์แบบ unique
        $ext = pathinfo($orig_name, PATHINFO_EXTENSION);
        $newName = 'prod_' . time() . '_' . rand(1000,9999) . '.' . $ext;

        $targetPath = $uploadDir . $newName;

        if (move_uploaded_file($tmp_name, $targetPath)) {
            // เก็บ path แบบ relative ไปใน DB เช่น "uploads/xxxx.jpg"
            $image_path = 'uploads/' . $newName;
        }
    }

    // validate ขั้นต้น
    if ($product_name === '' || $price === '' || $category_id === '' || $condition_status === '') {
        $message = '<div class="alert error">กรุณากรอกข้อมูลให้ครบก่อนเพิ่มสินค้า</div>';
    } else {
        // gen product_code ใหม่
        $product_code = generateProductCode($conn);

        $stmt = $conn->prepare("
            INSERT INTO products
            (product_code, product_name, product_detail, category_id, price, condition_status, image_path)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param(
            "sssisss",
            $product_code,
            $product_name,
            $product_detail,
            $category_id,
            $price,
            $condition_status,
            $image_path
        );

        if ($stmt->execute()) {
            $message = '<div class="alert success">เพิ่มสินค้าเรียบร้อย</div>';
        } else {
            $message = '<div class="alert error">เพิ่มสินค้าไม่สำเร็จ</div>';
        }
        $stmt->close();
    }
}

// ---------------------------
// ดึงหมวดหมู่ทั้งหมด (categories) ไว้ใส่ select
// ---------------------------
$categories = [];
$catRes = $conn->query("
    SELECT category_id, category_code, category_name
    FROM categories
    ORDER BY category_code ASC
");
while ($catRes && $row = $catRes->fetch_assoc()) {
    $categories[] = $row;
}

// ---------------------------
// ดึงสินค้าทั้งหมดเพื่อโชว์ในตาราง
// join เพื่อนำชื่อหมวดหมู่มาแสดง
// ---------------------------
$products = [];
$sqlList = "
SELECT p.product_id,
       p.product_code,
       p.product_name,
       p.product_detail,
       p.price,
       p.condition_status,
       p.image_path,
       p.created_at,
       c.category_name,
       c.category_code
FROM products p
LEFT JOIN categories c ON p.category_id = c.category_id
ORDER BY p.product_id DESC
";
$listRes = $conn->query($sqlList);
while ($listRes && $row = $listRes->fetch_assoc()) {
    $products[] = $row;
}

?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>จัดการสินค้า | Camping Hand</title>
    <link rel="preconnect" href="https://fonts.gstatic.com"/>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet"/>
    <style>
        :root {
            --bg-page:#f7f9fc;
            --card-bg:#fff;
            --border:#e4e4e4;
            --text-main:#1a1a1a;
            --text-dim:#6b6b6b;
            --accent:#ff4d30;
            --radius-lg:12px;
            --radius-sm:8px;
            --shadow-card:0 16px 32px rgba(0,0,0,.07);
        }
        *{
            box-sizing:border-box;
            font-family:'Inter',system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;
            margin:0;
            padding:0;
        }
        body{
            background:var(--bg-page);
            color:var(--text-main);
            min-height:100vh;
            display:flex;
            flex-direction:column;
        }

        /* header bar */
        .topbar{
            width:100%;
            background:#fff;
            border-bottom:1px solid var(--border);
            padding:12px 16px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            font-size:.9rem;
        }
        .left-head{
            font-weight:600;
            display:flex;
            align-items:center;
            gap:8px;
            color:#1a1a1a;
        }
        .admin-pill{
            background:#ffe4de;
            color:#ff4d30;
            font-size:.7rem;
            font-weight:600;
            border-radius:999px;
            padding:2px 8px;
        }
        .right-head{
            display:flex;
            gap:16px;
            font-size:.8rem;
        }
        .right-head a{
            font-weight:600;
            text-decoration:none;
            color:#1a1a1a;
        }
        .logout-link{
            color:#ff4d30;
        }

        main{
            flex:1;
            width:100%;
            max-width:1100px;
            margin:24px auto 32px;
            padding:0 16px;
        }

        .section-card{
            background:var(--card-bg);
            border:1px solid var(--border);
            border-radius:var(--radius-lg);
            box-shadow:var(--shadow-card);
            padding:20px 16px;
            margin-bottom:24px;
        }

        .section-head{
            display:flex;
            align-items:center;
            flex-wrap:wrap;
            gap:8px 12px;
            font-size:1.05rem;
            font-weight:600;
            color:#1a1a1a;
            margin-bottom:16px;
        }
        .section-head .icon{
            font-size:1rem;
        }

        form.add-product-form{
            display:flex;
            flex-wrap:wrap;
            align-items:flex-start;
            gap:12px;
        }
        .form-field{
            display:flex;
            flex-direction:column;
            font-size:.8rem;
            font-weight:500;
            color:#1a1a1a;
        }
        .form-field label{
            margin-bottom:4px;
        }
        .form-field input[type="text"],
        .form-field input[type="number"],
        .form-field select,
        .form-field textarea {
            min-width:180px;
            border:1px solid var(--border);
            border-radius:var(--radius-sm);
            padding:8px 10px;
            font-size:.9rem;
            background:#fff;
        }
        .form-field textarea{
            min-width:260px;
            min-height:60px;
            resize:vertical;
        }
        .file-field input[type="file"]{
            font-size:.8rem;
        }

        .btn-add{
            border:none;
            border-radius:var(--radius-sm);
            font-weight:600;
            font-size:.9rem;
            padding:10px 14px;
            cursor:pointer;
            min-width:120px;
            transition:.15s;
            box-shadow:0 12px 24px rgba(0,0,0,.12);
        }
        .btn-disabled{
            background:#cfcfcf;
            color:#777;
            cursor:not-allowed;
            box-shadow:none;
        }
        .btn-active{
            background:linear-gradient(to bottom right,#facc15,#eab308);
            color:#1a1a1a;
        }

        /* table */
        .table-wrapper{
            border:1px solid var(--border);
            border-radius:var(--radius-lg);
            overflow:hidden;
            background:#fff;
            box-shadow:var(--shadow-card);
        }
        table{
            width:100%;
            border-collapse:collapse;
            font-size:.85rem;
        }
        thead{
            background:#f4f4f4;
            font-weight:600;
            color:#1a1a1a;
        }
        th, td{
            text-align:left;
            padding:12px 16px;
            border-bottom:1px solid var(--border);
            vertical-align:middle;
        }
        tbody tr:last-child td{
            border-bottom:none;
        }
        .img-thumb{
            width:50px;
            height:50px;
            border-radius:6px;
            border:1px solid var(--border);
            object-fit:cover;
            background:#fafafa;
        }

        .actions-cell{
            display:flex;
            gap:8px;
        }
        .btn-edit{
            background:#2563eb;
            color:#fff;
            border:none;
            border-radius:6px;
            padding:6px 10px;
            font-size:.8rem;
            font-weight:600;
            cursor:pointer;
        }
        .btn-del{
            background:#dc2626;
            color:#fff;
            border:none;
            border-radius:6px;
            padding:6px 10px;
            font-size:.8rem;
            font-weight:600;
            cursor:pointer;
        }

        .alert{
            border-radius:8px;
            padding:10px 12px;
            font-size:.8rem;
            font-weight:500;
            margin-bottom:12px;
        }
        .alert.error{
            background:#ffe5e0;
            color:#d20000;
            border:1px solid #ffb6a8;
        }
        .alert.success{
            background:#e0ffe5;
            color:#007a1a;
            border:1px solid #a6ecb8;
        }

        footer{
            text-align:center;
            font-size:.7rem;
            color:#6b6b6b;
            padding:24px 16px 32px;
        }

        @media(max-width:768px){
            form.add-product-form{
                flex-direction:column;
                align-items:stretch;
            }
            .form-field,
            .file-field{
                width:100%;
            }
        }
    </style>
</head>
<body>

<header class="topbar">
    <div class="left-head">
        <span style="font-weight:600;">Camping Hand</span>
        <span class="admin-pill">Admin</span>
    </div>
    <div class="right-head">
        <a href="admin.php">กลับหน้าในหลัก</a>
        <a class="logout-link" href="logout.php">ออกจากระบบ</a>
    </div>
</header>

<main>

    <!-- ฟอร์มเพิ่มสินค้า -->
    <section class="section-card">
        <div class="section-head">
            <span class="icon">➕</span>
            <span>เพิ่มสินค้าใหม่</span>
        </div>

        <?php echo $message; ?>

        <form class="add-product-form" method="POST" action="admin_products.php" enctype="multipart/form-data" id="productForm">
            <input type="hidden" name="action" value="add_product"/>

            <div class="form-field">
                <label>ชื่อสินค้า *</label>
                <input type="text" name="product_name" id="product_name" placeholder="เช่น เต็นท์นอน 2 คน" required>
            </div>

            <div class="form-field">
                <label>ราคา (฿) *</label>
                <input type="number" step="0.01" name="price" id="price" placeholder="เช่น 1290" required>
            </div>

            <div class="form-field">
                <label>หมวดหมู่ *</label>
                <select name="category_id" id="category_id" required>
                    <option value="">-- เลือกหมวดหมู่ --</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo htmlspecialchars($cat['category_id']); ?>">
                            <?php echo htmlspecialchars($cat['category_name']); ?> (<?php echo htmlspecialchars($cat['category_code']); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-field">
                <label>สภาพสินค้า *</label>
                <input type="text" name="condition_status" id="condition_status" placeholder="เช่น ใหม่แกะกล่อง / มือสองสภาพดี" required>
            </div>

            <div class="form-field" style="flex:1; min-width:240px;">
                <label>รายละเอียดสินค้า</label>
                <textarea name="product_detail" id="product_detail" placeholder="รายละเอียด เช่น วัสดุ ขนาด น้ำหนัก จุดเด่น"></textarea>
            </div>

            <div class="file-field form-field">
                <label>รูปภาพสินค้า</label>
                <input type="file" name="image" id="image">
            </div>

            <div class="form-field" style="align-self:flex-end;">
                <button class="btn-add btn-disabled" id="addBtn" type="submit" disabled>
                    🛒 เพิ่มสินค้า
                </button>
            </div>
        </form>
    </section>

    <!-- ตารางสินค้า -->
    <section class="section-card">
        <div class="section-head">
            <span class="icon">📦</span>
            <span>รายการสินค้าทั้งหมด</span>
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>รหัส</th>
                        <th>รูปภาพ</th>
                        <th>ชื่อสินค้า</th>
                        <th>หมวดหมู่</th>
                        <th>ราคา</th>
                        <th>สภาพ</th>
                        <th>วันที่ลงขาย</th>
                        <th style="text-align:center;">จัดการ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($products) === 0): ?>
                        <tr>
                            <td colspan="8" style="text-align:center; color:#999; padding:24px 0;">
                                ยังไม่มีสินค้า
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($products as $p): ?>
                            <tr>
                                <td>#<?php echo htmlspecialchars($p['product_code']); ?></td>
                                <td>
                                    <?php if (!empty($p['image_path'])): ?>
                                        <img class="img-thumb" src="<?php echo htmlspecialchars($p['image_path']); ?>" alt="">
                                    <?php else: ?>
                                        <div class="img-thumb" style="display:flex;align-items:center;justify-content:center;font-size:.7rem;color:#999;">ไม่มีรูป</div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($p['product_name']); ?></td>
                                <td>
                                    <?php
                                      echo !empty($p['category_name'])
                                        ? htmlspecialchars($p['category_name']) . " (" . htmlspecialchars($p['category_code']) . ")"
                                        : "-";
                                    ?>
                                </td>
                                <td><?php echo number_format($p['price'], 2); ?> ฿</td>
                                <td><?php echo htmlspecialchars($p['condition_status'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($p['created_at']); ?></td>
                                <td style="text-align:center;">
                                    <div class="actions-cell">
    <a href="admin_product_edit.php?id=<?= $p['product_id'] ?>"
       class="btn-edit">✏️</a>
    <a href="admin_product_delete.php?id=<?= $p['product_id'] ?>"
       class="btn-del"
       onclick="return confirm('แน่ใจนะว่าจะลบสินค้านี้?');">🗑️</a>
</div>

                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<footer>
    © 2025 Camping Hand — ระบบจัดการร้านค้า
</footer>

<script>
// ปุ่มเพิ่มสินค้าเป็นเทาจนกว่าจะกรอกครบฟิลด์บังคับ
const requiredFields = [
    'product_name',
    'price',
    'category_id',
    'condition_status'
];
const addBtn = document.getElementById('addBtn');

function checkFormFilled() {
    let ok = true;
    requiredFields.forEach(id => {
        const el = document.getElementById(id);
        if (!el || el.value.trim() === '') {
            ok = false;
        }
    });
    if (ok) {
        addBtn.disabled = false;
        addBtn.classList.remove('btn-disabled');
        addBtn.classList.add('btn-active');
    } else {
        addBtn.disabled = true;
        addBtn.classList.add('btn-disabled');
        addBtn.classList.remove('btn-active');
    }
}

requiredFields.forEach(id => {
    const el = document.getElementById(id);
    if (el) {
        el.addEventListener('input', checkFormFilled);
        el.addEventListener('change', checkFormFilled);
    }
});

checkFormFilled();
</script>

</body>
</html>
