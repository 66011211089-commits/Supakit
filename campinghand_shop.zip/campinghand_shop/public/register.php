<?php
session_start();
require_once __DIR__ . '/../config/db.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $address  = trim($_POST['address'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';
    $invite_code = trim($_POST['invite_code'] ?? '');

    // ตั้งรหัสเชิญจริง (มึงเปลี่ยนได้เลย)
    $admin_key = 'CAMPADMIN2025';

    // ถ้ารหัสเชิญถูก -> สมัครเป็น admin
    $role = ($invite_code === $admin_key) ? 'admin' : 'user';

    if ($username === '' || $email === '' || $password === '' || $confirm === '') {
        $message = '<div class="alert error">กรุณากรอกข้อมูลที่จำเป็นให้ครบ *</div>';
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = '<div class="alert error">อีเมลไม่ถูกต้อง</div>';
    } else if ($password !== $confirm) {
        $message = '<div class="alert error">รหัสผ่านไม่ตรงกัน</div>';
    } else {
        $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $message = '<div class="alert error">อีเมลนี้ถูกใช้ไปแล้ว</div>';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);

            $stmtInsert = $conn->prepare("
                INSERT INTO users (username, email, phone, address, password_hash, role)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmtInsert->bind_param("ssssss", $username, $email, $phone, $address, $hash, $role);

            if ($stmtInsert->execute()) {
                if ($role === 'admin') {
                    $message = '<div class="alert success">✅ สมัครสำเร็จ! บัญชีนี้เป็นผู้ดูแลระบบ (Admin)</div>';
                } else {
                    $message = '<div class="alert success">✅ สมัครสมาชิกสำเร็จ! เข้าสู่ระบบได้เลย</div>';
                }
            } else {
                $message = '<div class="alert error">เกิดข้อผิดพลาดในการบันทึกข้อมูล</div>';
            }
            $stmtInsert->close();
        }
        $stmt->close();
    }
}

include __DIR__ . "/includes/header.php";
?>

<div class="auth-card">
    <div class="auth-head">
        <div class="auth-title">สมัครสมาชิก</div>
        <div class="auth-desc">
            กรอกข้อมูลด้านล่างเพื่อสร้างบัญชีใหม่และเริ่มช้อปได้เลย<br>
            <span style="font-size:0.8rem;color:#ff4d30;">(ใส่รหัสเชิญหากต้องการสมัครเป็น Admin)</span>
        </div>
    </div>

    <?php if ($message !== ""): ?>
        <div class="form-group" style="font-size:.85rem;line-height:1.4;">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="register.php" class="form-stack">
        <div class="form-group">
            <label>ชื่อผู้ใช้ *</label>
            <input type="text" name="username" placeholder="เช่น campinghand_user" required />
        </div>

        <div class="form-group">
            <label>อีเมล *</label>
            <input type="email" name="email" placeholder="you@example.com" required />
        </div>

        <div class="form-group">
            <label>เบอร์โทร</label>
            <input type="text" name="phone" placeholder="08x-xxx-xxxx" />
        </div>

        <div class="form-group">
            <label>ที่อยู่จัดส่ง</label>
            <textarea name="address" rows="2" placeholder="บ้านเลขที่ / ตำบล / อำเภอ / จังหวัด / รหัสไปรษณีย์"></textarea>
        </div>

        <div class="form-group">
            <label>รหัสผ่าน *</label>
            <input type="password" name="password" placeholder="อย่างน้อย 6 ตัวอักษร" required />
        </div>

        <div class="form-group">
            <label>ยืนยันรหัสผ่าน *</label>
            <input type="password" name="confirm_password" placeholder="พิมพ์รหัสผ่านซ้ำ" required />
        </div>

        <div class="form-group">
            <label>รหัสเชิญ (สำหรับสมัครแอดมิน)</label>
            <input type="text" name="invite_code" placeholder="เช่น CAMPADMIN2025" />
        </div>

        <button class="btn-submit" type="submit">สร้างบัญชี</button>
    </form>

    <div class="bottom-row">
        มีบัญชีอยู่แล้ว? <a href="login.php">เข้าสู่ระบบ</a>
    </div>
</div>

<?php include __DIR__ . "/includes/footer.php"; ?>
