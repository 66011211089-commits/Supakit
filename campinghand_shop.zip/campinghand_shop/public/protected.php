<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}
include __DIR__ . "/includes/header.php";
?>
<div class="auth-card" style="max-width:480px;">
    <div class="auth-head">
        <div class="auth-title">ยินดีต้อนรับ 🎉</div>
        <div class="auth-desc">
            คุณล็อกอินอยู่ในระบบแล้ว<br>
            user: <b><?php echo htmlspecialchars($_SESSION['username']); ?></b><br>
            role: <b><?php echo htmlspecialchars($_SESSION['role']); ?></b>
        </div>
    </div>

    <a class="btn-submit" href="logout.php" style="text-align:center;display:block;text-decoration:none;">ออกจากระบบ</a>
</div>
<?php include __DIR__ . "/includes/footer.php"; ?>
