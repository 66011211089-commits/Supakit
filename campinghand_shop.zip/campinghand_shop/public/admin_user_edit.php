<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/includes/auth.php';

// ต้องเป็น admin เท่านั้น
require_role('admin');

$message = "";
$user = null;
$user_id = 0;

// 1. ตรวจสอบว่ามี ID ส่งมาหรือไม่
if (!isset($_GET['id'])) {
    header("Location: admin_users.php");
    exit;
}
$user_id = intval($_GET['id']);

// 2. ดึงข้อมูลผู้ใช้เดิมจาก ID
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
} else {
    // ไม่พบผู้ใช้
    header("Location: admin_users.php");
    exit;
}
$stmt->close();

// 3. ถ้ามีการ POST (กดบันทึก)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $role     = trim($_POST['role'] ?? 'user'); // ค่า default คือ user

    // ป้องกันแอดมินเปลี่ยนสิทธิ์ตัวเองเป็น user (กันพลาด)
    $current_admin_id = $_SESSION['user_id'] ?? 0;
    if ($user_id === $current_admin_id && $role !== 'admin') {
         $message = '<div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
            <strong class="font-bold">ผิดพลาด!</strong>
            <span class="block sm:inline">คุณไม่สามารถเปลี่ยนสิทธิ์ของตัวเองออกจากแอดมินได้</span>
          </div>';
         // ตั้งค่า role กลับเป็น admin
         $role = 'admin';
         $user['role'] = 'admin'; // อัปเดตตัวแปรที่จะแสดงในฟอร์มด้วย
    } else {
        // อัปเดตข้อมูล
        $update_stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, phone = ?, role = ? WHERE user_id = ?");
        $update_stmt->bind_param("ssssi", $username, $email, $phone, $role, $user_id);
        
        if ($update_stmt->execute()) {
            $message = '<div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                <strong class="font-bold">สำเร็จ!</strong>
                <span class="block sm:inline">อัปเดตข้อมูลผู้ใช้เรียบร้อยแล้ว</span>
              </div>';
            // อัปเดตข้อมูลใน $user เพื่อให้ฟอร์มแสดงข้อมูลใหม่ทันที
            $user['username'] = $username;
            $user['email'] = $email;
            $user['phone'] = $phone;
            $user['role'] = $role;
        } else {
             $message = '<div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong class="font-bold">ผิดพลาด!</strong>
                <span class="block sm:inline">ไม่สามารถอัปเดตข้อมูลได้ (อาจจะอีเมลซ้ำ)</span>
              </div>';
        }
        $update_stmt->close();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>แก้ไขผู้ใช้ #<?= $user['user_id'] ?> | Camping Hand Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body class="bg-gray-100 font-sans">

    <!-- Header -->
    <header class="bg-white shadow-md">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                 <div class="flex items-center">
                    <h1 class="text-xl font-bold text-gray-800">
                        Camping Hand <span class="text-red-500 text-xs bg-red-100 px-2 py-1 rounded-md ml-2">Admin</span>
                    </h1>
                </div>
                <div class="flex items-center space-x-4 text-sm">
                    <a href="logout.php" class="text-red-500 hover:text-red-700 font-medium">
                        <i class="fa-solid fa-right-from-bracket mr-1"></i>
                        ออกจากระบบ
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="max-w-xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        
        <a href="admin_users.php" class="text-sm text-blue-600 hover:text-blue-800 mb-4 inline-block">
            <i class="fa-solid fa-arrow-left mr-1"></i>
            กลับไปหน้ารายการผู้ใช้
        </a>
        
        <h2 class="text-2xl font-bold text-gray-900 mb-6">
            <i class="fa-solid fa-user-pen mr-2"></i>
            แก้ไขผู้ใช้งาน (ID: <?= $user['user_id'] ?>)
        </h2>

        <!-- Form -->
        <form method="POST" action="admin_user_edit.php?id=<?= $user['user_id'] ?>" class="bg-white shadow-lg rounded-xl p-6 sm:p-8 space-y-6">
            
            <?= $message ?> <!-- แสดงข้อความ (สำเร็จ/ผิดพลาด) -->

            <div>
                <label for="username" class="block text-sm font-medium text-gray-700 mb-1">ชื่อผู้ใช้ (Username)</label>
                <input type="text" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <div>
                <label for="email" class="block text-sm font-medium text-gray-700 mb-1">อีเมล</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <div>
                <label for="phone" class="block text-sm font-medium text-gray-700 mb-1">เบอร์โทร</label>
                <input type="tel" id="phone" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                       placeholder="เช่น 08xxxxxxxx">
            </div>

            <div>
                <label for="role" class="block text-sm font-medium text-gray-700 mb-1">สิทธิ์การใช้งาน (Role)</label>
                <select id="role" name="role" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
                    <option value="user" <?= $user['role'] === 'user' ? 'selected' : '' ?>>
                        Customer (ผู้ใช้งานทั่วไป)
                    </option>
                    <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>
                        Admin (ผู้ดูแลระบบ)
                    </option>
                </select>
                <?php if ($user_id === ($_SESSION['user_id'] ?? 0)): ?>
                    <p class="text-xs text-red-600 mt-1">
                        <i class="fa-solid fa-triangle-exclamation mr-1"></i>
                        คุณไม่สามารถเปลี่ยนสิทธิ์ของบัญชีตัวเองได้
                    </p>
                <?php endif; ?>
            </div>
            
            <div class="text-gray-500 text-xs pt-4 border-t">
                วันที่สมัคร: <?= date('d M Y, H:i', strtotime($user['created_at'])) ?>
            </div>

            <!-- Buttons -->
            <div class="flex justify-end pt-4">
                <button type="submit"
                        class="bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-2 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    <i class="fa-solid fa-save mr-2"></i>
                    บันทึกการเปลี่ยนแปลง
                </button>
            </div>

        </form>

    </main>

    <footer class="text-center text-gray-500 text-xs py-10">
        © <?= date('Y') ?> Camping Hand — ระบบจัดการร้านค้า
    </footer>

</body>
</html>
