<?php
function csrf_token(){ if(empty($_SESSION['csrf_token'])){ $_SESSION['csrf_token']=bin2hex(random_bytes(32)); } return $_SESSION['csrf_token']; }
function csrf_field(){ $t=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8'); echo '<input type="hidden" name="csrf_token" value="'.$t.'">'; }
function verify_csrf(){ if(empty($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')){ http_response_code(400); die('Invalid CSRF token.'); } }
