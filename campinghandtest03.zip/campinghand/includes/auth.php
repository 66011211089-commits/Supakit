<?php
require_once __DIR__.'/../config/db.php';
function current_user(){ if(!empty($_SESSION['user_id'])){ return ['id'=>$_SESSION['user_id'],'name'=>$_SESSION['user_name']??null,'email'=>$_SESSION['user_email']??null,'role'=>$_SESSION['user_role']??null]; } return null; }
function is_logged_in(){ return !empty($_SESSION['user_id']); }
function require_login(){ if(!is_logged_in()){ header('Location: /login.php'); exit; } }
function require_role($role){ require_login(); if(($_SESSION['user_role']??null)!==$role){ http_response_code(403); die('Forbidden'); } }
function login_user($u){ $_SESSION['user_id']=$u['id']; $_SESSION['user_name']=$u['name']; $_SESSION['user_email']=$u['email']; $_SESSION['user_role']=$u['role']; }
function logout_user(){ $_SESSION=[]; if(ini_get('session.use_cookies')){ $p=session_get_cookie_params(); setcookie(session_name(),'',
 time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']); } session_destroy(); }
