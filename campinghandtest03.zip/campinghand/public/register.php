<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
$err=null;$ok=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
  verify_csrf();
  $name=trim($_POST['name']??''); $email=trim($_POST['email']??''); $password=$_POST['password']??''; $confirm=$_POST['confirm']??'';
  $wants_admin=(($_POST['want_admin']??'')==='1'); $invite_code=trim($_POST['invite_code']??'');
  if($name===''||$email===''||$password===''||$confirm===''){ $err='กรอกข้อมูลให้ครบ'; }
  elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){ $err='รูปแบบอีเมลไม่ถูกต้อง'; }
  elseif($password!==$confirm){ $err='รหัสผ่านไม่ตรงกัน'; }
  elseif($wants_admin && $invite_code!==ADMIN_INVITE_CODE){ $err='โค้ดเชิญสำหรับ Admin ไม่ถูกต้อง'; }
  else{
    $check=$pdo->prepare('SELECT id FROM users WHERE email=? LIMIT 1'); $check->execute([$email]);
    if($check->fetch()){ $err='อีเมลนี้ถูกใช้ไปแล้ว'; }
    else{
      $hash=password_hash($password,PASSWORD_BCRYPT); $role=$wants_admin?'admin':'user';
      $ins=$pdo->prepare('INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,?)'); $ins->execute([$name,$email,$hash,$role]);
      $ok='สมัครสมาชิกสำเร็จ! ลองเข้าสู่ระบบได้เลย';
    }
  }
}
?><!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Camping Hand — Register</title><link rel="stylesheet" href="/assets/styles.css"></head>
<body><header class="header"><div class="container nav"><div class="brand">Camping Hand <span class="badge">Beta</span></div><div style="margin-left:auto"></div><a href="/login.php">เข้าสู่ระบบ</a></div></header>
<main class="container" style="margin-top:24px;"><div class="card" style="max-width:720px; margin:0 auto;"><h1>สมัครสมาชิก</h1><div class="helper">กรอกข้อมูลด้านล่างเพื่อสร้างบัญชีใหม่</div>
<?php if($err): ?><div class="error"><?= htmlspecialchars($err) ?></div><?php endif; ?><?php if($ok): ?><div class="success"><?= htmlspecialchars($ok) ?></div><?php endif; ?>
<form method="post" action="/register.php" style="display:grid; gap:12px;"><?php csrf_field(); ?>
<div class="row"><div><label class="label">ชื่อ</label><input class="input" type="text" name="name" required></div>
<div><label class="label">อีเมล</label><input class="input" type="email" name="email" required></div></div>
<div class="row"><div><label class="label">รหัสผ่าน</label><input class="input" type="password" name="password" required></div>
<div><label class="label">ยืนยันรหัสผ่าน</label><input class="input" type="password" name="confirm" required></div></div>
<div class="card" style="background:#fff9f8;"><b>สมัครเป็น Admin?</b>
<div class="helper">ใส่โค้ดเชิญสำหรับ Admin (ค่าเริ่มต้นคือ <code>CH-ADMIN-123</code> ใน config/db.php)</div>
<div class="row"><div><label class="label">โค้ดเชิญ (ถ้ามี)</label><input class="input" type="text" name="invite_code" placeholder="CH-ADMIN-123"></div>
<div><label class="label">เลือกสถานะ</label><select class="input" name="want_admin"><option value="0">User</option><option value="1">Admin (ต้องมีโค้ด)</option></select></div></div></div>
<button class="btn" type="submit">สร้างบัญชี</button><div class="helper">มีบัญชีแล้ว? <a href="/login.php">เข้าสู่ระบบ</a></div></form></div><div class="footer">© Camping Hand</div></main></body></html>
