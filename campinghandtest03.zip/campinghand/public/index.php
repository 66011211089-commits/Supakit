<?php
require_once __DIR__.'/../includes/auth.php';
$user=current_user();
if($user){ if($user['role']==='admin'){ header('Location: /admin.php'); } else { header('Location: /user.php'); } exit; }
header('Location: /login.php'); exit;
