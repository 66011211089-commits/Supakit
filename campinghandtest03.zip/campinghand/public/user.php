<?php
require_once __DIR__.'/../includes/auth.php'; require_role('user'); $user=current_user();
?><!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Camping Hand — User</title><link rel="stylesheet" href="/assets/styles.css"></head>
<body><header class="header"><div class="container nav"><div class="brand">Camping Hand <span class="badge">User</span></div>
<div style="margin-left:auto"></div><span class="helper">สวัสดี, <?= htmlspecialchars($user['name']) ?></span><a href="/logout.php">ออกจากระบบ</a></div></header>
<main class="container" style="margin-top:24px;"><div class="card"><h2>หน้าโฮมผู้ใช้</h2>
<div class="helper">รอใส่: ฟีดสินค้า, ตะกร้า, ออเดอร์, แชท</div><ul><li>สินค้าแนะนำ (coming soon)</li><li>หมวดหมู่ (coming soon)</li></ul></div></main></body></html>
