<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('user');

$id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare("
  SELECT o.*, u.name AS buyer
  FROM orders o
  JOIN users u ON o.user_id = u.id
  WHERE o.id = ? AND o.user_id = ?
");
$stmt->execute([$id, $_SESSION['user_id']]);
$order = $stmt->fetch();
if (!$order) die('ไม่พบคำสั่งซื้อ');

$items = $pdo->prepare("
  SELECT oi.*, p.name, p.price, p.image
  FROM order_items oi
  JOIN products p ON oi.product_id = p.id
  WHERE oi.order_id = ?
");
$items->execute([$id]);
$list = $items->fetchAll();
?>
<!doctype html>
<html lang=\"th\">
<head>
  <meta charset=\"utf-8\">
  <title>รายละเอียดคำสั่งซื้อ #<?= $order['id'] ?> - Camping Hand</title>
  <link rel=\"stylesheet\" href=\"/assets/styles.css\">
</head>
<body>
  <header class=\"header\">
    <div class=\"container nav\">
      <div class=\"brand\">Camping Hand <span class=\"badge\">Order #<?= $order['id'] ?></span></div>
      <a href=\"/orders.php\">ย้อนกลับ</a>
    </div>
  </header>
  <main class=\"container\" style=\"margin-top:24px;\">
    <h1>รายละเอียดคำสั่งซื้อ #<?= $order['id'] ?></h1>
    <p>ผู้สั่งซื้อ: <?= htmlspecialchars($order['buyer']) ?><br>
    วันที่: <?= $order['created_at'] ?><br>
    ยอดรวม: <b><?= number_format($order['total_amount'],2) ?> บาท</b></p>
    <table class=\"table\">
      <tr><th>สินค้า</th><th>ราคา</th><th>จำนวน</th><th>รวม</th></tr>
      <?php foreach ($list as $i): ?>
      <tr>
        <td>
          <img src=\"<?= $i['image'] ? '/uploads/'.htmlspecialchars($i['image']) : 'https://via.placeholder.com/60' ?>\" width=\"60\" height=\"60\" style=\"object-fit:cover;border-radius:6px;vertical-align:middle;\"> 
          <?= htmlspecialchars($i['name']) ?>
        </td>
        <td><?= number_format($i['price'],2) ?> ฿</td>
        <td><?= $i['quantity'] ?></td>
        <td><?= number_format($i['price']*$i['quantity'],2) ?> ฿</td>
      </tr>
      <?php endforeach; ?>
    </table>
  </main>
</body>
</html>
