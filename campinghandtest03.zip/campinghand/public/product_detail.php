<?php
require_once __DIR__ . '/../includes/auth.php';
$id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare("
  SELECT p.*, c.name AS cat_name, u.name AS seller
  FROM products p
  LEFT JOIN categories c ON p.category_id = c.id
  LEFT JOIN users u ON p.user_id = u.id
  WHERE p.id = ?
");
$stmt->execute([$id]);
$p = $stmt->fetch();
if (!$p) { die('ไม่พบสินค้า'); }
?>
<!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($p['name']) ?> - Camping Hand</title>
  <link rel="stylesheet" href="/assets/styles.css">
</head>
<body>
  <header class="header">
    <div class="container nav">
      <div class="brand">Camping Hand <span class="badge">รายละเอียดสินค้า</span></div>
      <a href="/products.php">ย้อนกลับ</a>
    </div>
  </header>

  <main class="container" style="margin-top:24px;">
    <div class="card" style="max-width:800px;margin:auto;display:flex;gap:20px;flex-wrap:wrap;">
      <img src="<?= $p['image'] ? '/uploads/'.htmlspecialchars($p['image']) : 'https://via.placeholder.com/400x300?text=No+Image' ?>"
           style="width:300px;height:300px;object-fit:cover;border-radius:10px;">
      <div style="flex:1;min-width:250px;">
        <h1><?= htmlspecialchars($p['name']) ?></h1>
        <div class="pprice">ราคา: <?= number_format($p['price'],2) ?> บาท</div>
        <div class="helper">หมวดหมู่: <?= htmlspecialchars($p['cat_name'] ?? '-') ?></div>
        <div class="helper">ผู้ขาย: <?= htmlspecialchars($p['seller'] ?? '-') ?></div>
        <p style="margin-top:10px;">
          <b>รายละเอียดสินค้า:</b><br>
          <?= nl2br(htmlspecialchars($p['description'])) ?>
        </p>
        <div style="margin-top:20px;display:flex;gap:10px;">
          <a class="btn" href="/cart_add.php?id=<?= $p['id'] ?>">เพิ่มลงตะกร้า</a>
          <a class="btn" style="background:var(--brand-dark);" href="/cart.php">ไปหน้าตะกร้า</a>
        </div>
      </div>
    </div>
  </main>
</body>
</html>
