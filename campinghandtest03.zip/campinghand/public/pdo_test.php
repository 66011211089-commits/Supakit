<?php
require_once __DIR__ . '/../config/db.php';
echo $pdo->query("SELECT 1")->fetchColumn() ? "OK" : "NG";
