<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('user'); // เฉพาะ user เห็นหน้านี้ได้
$products = $pdo->query("
  SELECT p.*, c.name AS cat_name, u.name AS seller
  FROM products p
  LEFT JOIN categories c ON p.category_id = c.id
  LEFT JOIN users u ON p.user_id = u.id
  ORDER BY p.created_at DESC
")->fetchAll();
?>
<!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8">
  <title>สินค้าทั้งหมด - Camping Hand</title>
  <link rel="stylesheet" href="/assets/styles.css">
  <style>
    .grid {display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px;}
    .item {border:1px solid var(--border);border-radius:10px;overflow:hidden;background:#fff;}
    .item img{width:100%;height:180px;object-fit:cover;}
    .pbox{padding:10px;}
    .pname{font-weight:700;margin-bottom:6px;}
    .pprice{color:var(--brand);}
  </style>
</head>
<body>
  <header class="header">
    <div class="container nav">
      <div class="brand">Camping Hand <span class="badge">User</span></div>
      <div style="margin-left:auto"></div>
      <a href="/logout.php">ออกจากระบบ</a>
    </div>
  </header>
  <main class="container" style="margin-top:24px;">
    <h1>รายการสินค้า</h1>
    <div class="grid">
      <?php foreach ($products as $p): ?>
        <div class="item">
          <img src="<?= $p['image'] ? '/uploads/'.htmlspecialchars($p['image']) : 'https://via.placeholder.com/300x200?text=No+Image' ?>">
          <div class="pbox">
            <div class="pname"><?= htmlspecialchars($p['name']) ?></div>
            <div class="pprice"><?= number_format($p['price'],2) ?> บาท</div>
            <div class="helper">หมวด: <?= htmlspecialchars($p['cat_name'] ?? '-') ?></div>
            <a class="btn" style="width:100%;margin-top:8px;" href="/product_detail.php?id=<?= $p['id'] ?>">ดูรายละเอียด</a>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </main>
</body>
</html>
