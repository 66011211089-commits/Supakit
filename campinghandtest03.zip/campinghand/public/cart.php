<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('user');

// เพิ่ม / ลด จำนวน
if (isset($_GET['action'], $_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'];

    if ($action === 'inc') {
        $pdo->prepare("UPDATE cart SET quantity = quantity + 1 WHERE id = ? AND user_id = ?")->execute([$id, $_SESSION['user_id']]);
    } elseif ($action === 'dec') {
        $pdo->prepare("UPDATE cart SET quantity = GREATEST(quantity - 1, 1) WHERE id = ? AND user_id = ?")->execute([$id, $_SESSION['user_id']]);
    }
    header("Location: /cart.php");
    exit;
}

// ลบสินค้า
if (isset($_GET['remove'])) {
    $rid = intval($_GET['remove']);
    $pdo->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?")->execute([$rid, $_SESSION['user_id']]);
    header("Location: /cart.php");
    exit;
}

// ยืนยันสั่งซื้อ (จำลอง)
if (isset($_GET['checkout'])) {
    echo "<script>alert('สั่งซื้อเรียบร้อย (จำลอง)'); window.location='/checkout.php';</script>";
    exit;
}

// โหลดสินค้าในตะกร้า
$items = $pdo->prepare("
  SELECT c.*, p.name, p.price, p.image 
  FROM cart c
  JOIN products p ON c.product_id = p.id
  WHERE c.user_id = ?
");
$items->execute([$_SESSION['user_id']]);
$cart = $items->fetchAll();

$total = 0;
foreach ($cart as $i) $total += $i['price'] * $i['quantity'];
?>
<!doctype html>
<html lang="th">
<head>
  <meta charset="utf-8">
  <title>ตะกร้าสินค้า - Camping Hand</title>
  <link rel="stylesheet" href="/assets/styles.css">
  <style>
    .table {width:100%;border-collapse:collapse;margin-top:16px;}
    th,td {border:1px solid var(--border);padding:8px;text-align:center;}
    th{background:#f7f7f7;}
    img{width:60px;height:60px;object-fit:cover;border-radius:6px;}
    .qty-btn{padding:4px 10px;border:none;border-radius:5px;background:var(--brand);color:#fff;cursor:pointer;}
    .qty-btn:hover{background:#ff7a00;}
  </style>
</head>
<body>
  <header class="header">
    <div class="container nav">
      <div class="brand">Camping Hand <span class="badge">Cart</span></div>
      <div style="margin-left:auto"></div>
      <a href="/products.php">กลับไปดูสินค้า</a>
      <a href="/logout.php">ออกจากระบบ</a>
    </div>
  </header>

  <main class="container" style="margin-top:24px;">
    <h1>🛒 ตะกร้าสินค้าของคุณ</h1>
    <?php if (!$cart): ?>
      <div class="helper">ยังไม่มีสินค้าในตะกร้า</div>
    <?php else: ?>
      <table class="table">
        <tr>
          <th>สินค้า</th><th>ราคา</th><th>จำนวน</th><th>รวม</th><th></th>
        </tr>
        <?php foreach ($cart as $i): ?>
        <tr>
          <td style="text-align:left;">
            <img src="<?= $i['image'] ? '/uploads/'.htmlspecialchars($i['image']) : 'https://via.placeholder.com/60' ?>">
            <?= htmlspecialchars($i['name']) ?>
          </td>
          <td><?= number_format($i['price'],2) ?> ฿</td>
          <td>
            <a class="qty-btn" href="/cart.php?action=dec&id=<?= $i['id'] ?>">−</a>
            <?= $i['quantity'] ?>
            <a class="qty-btn" href="/cart.php?action=inc&id=<?= $i['id'] ?>">+</a>
          </td>
          <td><?= number_format($i['price'] * $i['quantity'],2) ?> ฿</td>
          <td><a href="/cart.php?remove=<?= $i['id'] ?>" style="color:red;">ลบ</a></td>
        </tr>
        <?php endforeach; ?>
      </table>
      <h2 style="text-align:right;">รวมทั้งหมด: <?= number_format($total,2) ?> บาท</h2>
      <div style="text-align:right;">
        <a class="btn" href="/cart.php?checkout=1">สั่งซื้อ (จำลอง)</a>
      </div>
    <?php endif; ?>
  </main>
</body>
</html>
