<?php
require_once __DIR__.'/../includes/auth.php'; require_role('admin'); $user=current_user();
?><!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Camping Hand — Admin</title><link rel="stylesheet" href="/assets/styles.css"></head>
<body><header class="header"><div class="container nav"><div class="brand">Camping Hand <span class="badge">Admin</span></div>
<div style="margin-left:auto"></div><span class="helper">สวัสดี, <?= htmlspecialchars($user['name']) ?></span><a href="/logout.php">ออกจากระบบ</a></div></header>
<main class="container" style="margin-top:24px;"><div class="card"><h2>แผงควบคุมผู้ดูแล</h2>
<div class="helper">รอใส่: จัดการสินค้า/ผู้ใช้/ออเดอร์/รีวิว</div><ul><li>สถิติ (coming soon)</li><li>เมนูลัด (coming soon)</li></ul></div></main></body></html>
